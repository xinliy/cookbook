package controller;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import SelfDefException.ExceptionClass;
import SelfDefException.InputException;
import business_logic.CookBook;
import business_logic.Ingredient;
import business_logic.Recipe;
import business_logic.Tag;
import view.Cover;
import view.Create_GUI;
import view.Edit_GUI;
import view.Search_GUI;
import view.View_GUI;
import view.DeleteWindow;

/**
 * The controller class which implements all the methods needed
 * 
 * @author Xiaoyue Zhang, Yuchao Song, Qiang Ma, Guanqi Bing, Xue Shan
 * @version 1.0
 */

public class Controller {

	private CookBook cookBook;
	private Create_GUI create_GUI;
	private DeleteWindow deleteWindow;
	private Edit_GUI edit_GUI;
	private Search_GUI search_GUI;
	private View_GUI view_GUI;
	private ExceptionClass exception;
	private int width;
	private int height;
	public Cover cover;

	/**
	 * Constructor which initializes all the interfaces and implements all the
	 * listeners to the buttons
	 * 
	 * @param create_GUI
	 *            =>The interface where new recipes are created
	 * @param deleteWindow
	 *            =>The interface which requires the user to confirm the
	 *            deletion of the recipe
	 * @param edit_GUI
	 *            =>The interface where the recipes can be edited
	 * @param search_GUI
	 *            =>The interface where the user can search and see the result
	 *            of recipes
	 * @param view_GUI
	 *            =>The interface where the detailed recipe information is
	 *            demonstrated
	 * @param cover
	 *            =>The interface which appears at the very beginning when the
	 *            user starts the software
	 */

	public Controller(Create_GUI create_GUI, DeleteWindow deleteWindow, Edit_GUI edit_GUI, Search_GUI search_GUI,
			View_GUI view_GUI, Cover cover) {

		this.cookBook = new CookBook();
		this.create_GUI = create_GUI;
		this.deleteWindow = deleteWindow;
		this.edit_GUI = edit_GUI;
		this.search_GUI = search_GUI;
		this.view_GUI = view_GUI;
		this.cover = cover;

		this.exception = new ExceptionClass();

		this.view_GUI.addListener(new Listener_View_Back(), View_GUI.backButton);
		this.view_GUI.addListener(new Listener_View_Edit(), View_GUI.editButton);
		this.view_GUI.addListener(new Listener_View_Delete(), View_GUI.deleteButton);
		this.view_GUI.addListener(new Listener_View_Refresh(), View_GUI.changeServings);

		this.create_GUI.addListener(new Listener_Create_AddIngredient(), Create_GUI.btnAdd);
		this.create_GUI.addListener(new Listener_Create_DeleteIngredient(), Create_GUI.btnDeleteIngredient);
		this.create_GUI.addListener(new Listener_Create_DeleteStep(), Create_GUI.deleteStepButton);
		this.create_GUI.addListener(new Listener_Create_Save(), Create_GUI.btnSave);
		this.create_GUI.addListener(new Listener_Create_Back(), Create_GUI.btnBack);
		this.create_GUI.addListener(new Listener_Create_AddStep(), Create_GUI.btnAddAStep);

		this.deleteWindow.addListener(new Listener_Delete_Confirm(), DeleteWindow.confirmButton);
		this.deleteWindow.addListener(new Listener_Delete_Cancel(), DeleteWindow.cancelButton);

		this.edit_GUI.addListener(new Listener_Edit_Back(), Edit_GUI.btnBack);
		this.edit_GUI.addListener(new Listener_Edit_Save(), Edit_GUI.btnSave);
		this.edit_GUI.addListener(new Listener_Edit_AddIngredient(), Edit_GUI.btnAddIngredient);
		this.edit_GUI.addListener(new Listener_Edit_DeleteIngredient(), Edit_GUI.btnDeleteIngredient);
		this.edit_GUI.addListener(new Listener_Edit_AddStep(), Edit_GUI.btnAddStep);
		this.edit_GUI.addListener(new Listener_Edit_DeleteStep(), Edit_GUI.btnDeleteStep);

		this.search_GUI.addMouseListener(new Listener_Search_SearchMouse(), Search_GUI.jtf_search);
		this.search_GUI.addKeyListener(new Listener_Search_SearchKey(), Search_GUI.jtf_search);
		this.search_GUI.addListener(new Listener_Search_SearchAdd(), Search_GUI.jb_add);
		this.search_GUI.addListener(new Listener_Search_Search(), Search_GUI.jb_search);

		this.cover.addListener(new Listener_Cover_GetEnter(), this.cover.getEnter());

		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		width = (int) dim.getWidth();
		height = (int) dim.getHeight();
		add_Search_SearchMouse();

	}

	/**
	 * Deriving the name of the recipe which the user has clicked on the
	 * Search_GUI and entering the specified viewing interface
	 */

	public void add_Search_SearchMouse() {

		for (int i = 0; i < 20; i++) {

			int j = i;
			Search_GUI.innerPanel[i].addMouseListener(new MouseAdapter() {

				public void mousePressed(MouseEvent e) {

					search_GUI.dispose();
					View_GUI.recipeName = Search_GUI.jl_name[j].getText();
					view_GUI.showGUI();
					ShowView();

					try {
						rebuild_View_GUI();
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
				}
			});
		}
	}

	/**
	 * Closing the cover interface and opening the Search_GUI
	 */

	class Listener_Cover_GetEnter implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			cover.dispose();
			search_GUI.showGUI();

		}
	}

	/**
	 * Generating the formatted result recipe box
	 */

	class Listener_Search_Search implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			Search_GUI.bottomPanel.removeAll();
			Search_GUI.box1.removeAll();
			Search_GUI.box_bottomPanelItem.removeAll();
			for (int i = 0; i < 20; i++) {
				Search_GUI.innerPanel[i].removeAll();
				Search_GUI.box_recipe[i].removeAll();
				Search_GUI.box_name[i].removeAll();
				Search_GUI.box_prepTime[i].removeAll();
				Search_GUI.box_cookTime[i].removeAll();
				Search_GUI.box_ingredients[i].removeAll();
				Search_GUI.box_flavor[i].removeAll();
				Search_GUI.box_bottomHoriBox[i].removeAll();
			}

			int targetRecipeNumber = 0;
			LinkedList<Recipe> targetRecipe = null;
			try {
				targetRecipeNumber = cookBook.searchByNameAndIngredient(Search_GUI.jtf_search.getText(),
						Search_GUI.jcb_flavor.getSelectedItem().toString()).size();
				targetRecipe = new LinkedList<Recipe>();
				for (int i = 0; i < targetRecipeNumber; i++) {
					targetRecipe.add(i, cookBook.searchByNameAndIngredient(Search_GUI.jtf_search.getText(),
							Search_GUI.jcb_flavor.getSelectedItem().toString()).get(i));
				}

			} catch (ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}

			if (targetRecipeNumber == 0) {
				JOptionPane.showMessageDialog(null, "No results found!");
			} else {

				Search_GUI.jl_result.setFont(new Font("Arial", Font.CENTER_BASELINE, (int) (width * 0.00878)));
				Search_GUI.jl_result.setForeground(Color.gray);

				Search_GUI.box1.add(Search_GUI.jl_result);
				Search_GUI.box1.add(Box.createHorizontalGlue());

				Search_GUI.bottomPanel.add(Search_GUI.box1);

				Search_GUI.box_bottomPanelItem.add(Search_GUI.box1);

				for (int j = 0; j < targetRecipeNumber; j++) {
					if (j % 2 == 0) {
						
						Search_GUI.innerPanel[j].setBorder(BorderFactory.createLineBorder(Color.gray));

						Search_GUI.jl_name[j].setText(targetRecipe.get(j).getDishName());
						Search_GUI.jl_name[j].setFont(new Font("Arial", Font.BOLD, (int) (width * 0.01317716)));
						Search_GUI.jl_name[j].setForeground(Color.black);
						Search_GUI.box_name[j].add(Search_GUI.jl_name[j]);
						Search_GUI.box_name[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_name[j]);

						Search_GUI.jl_prepTime[j].setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_prepTime[j].setForeground(Color.black);
						Search_GUI.box_prepTime[j].add(Search_GUI.jl_prepTime[j]);
						Search_GUI.jl_targetPrepTime[j].setText(targetRecipe.get(j).getPreparationTime() + "min");
						Search_GUI.jl_targetPrepTime[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetPrepTime[j].setForeground(Color.black);
						Search_GUI.box_prepTime[j].add(Search_GUI.jl_targetPrepTime[j]);
						Search_GUI.box_prepTime[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_prepTime[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						Search_GUI.jl_cookTime[j].setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_cookTime[j].setForeground(Color.black);
						Search_GUI.box_cookTime[j].add(Search_GUI.jl_cookTime[j]);
						Search_GUI.jl_targetCookTime[j].setText(targetRecipe.get(j).getCookingTime() + "min");
						Search_GUI.jl_targetCookTime[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetCookTime[j].setForeground(Color.black);
						Search_GUI.box_cookTime[j].add(Search_GUI.jl_targetCookTime[j]);
						Search_GUI.box_cookTime[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_cookTime[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						Search_GUI.jl_ingredients[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_ingredients[j].setForeground(Color.black);
						Search_GUI.box_ingredients[j].add(Search_GUI.jl_ingredients[j]);
						try {
							Search_GUI.jl_targetIngredients[j]
									.setText(cookBook.getAllIngredientsName(targetRecipe.get(j).getDishName()));
						} catch (ClassNotFoundException | SQLException e3) {
							e3.printStackTrace();
						}
						Search_GUI.jl_targetIngredients[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetIngredients[j].setForeground(Color.black);
						Search_GUI.box_ingredients[j].add(Search_GUI.jl_targetIngredients[j]);
						Search_GUI.box_ingredients[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_ingredients[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						try {
							for (int i = 0; i < cookBook.getAllTags(targetRecipe.get(j).getDishName()).size(); i++) {
								String targetTag = cookBook.getAllTags(targetRecipe.get(j).getDishName()).get(i);
								if (targetTag.equals("sweet")) {
									Search_GUI.jl_flavor1[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor1[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor1[j].setOpaque(true);
									Search_GUI.jl_flavor1[j].setBorder(BorderFactory.createLineBorder(Color.green));
									Search_GUI.jl_flavor1[j].setBackground(Color.green);
									Search_GUI.jl_flavor1[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor1[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("salty")) {
									Search_GUI.jl_flavor2[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor2[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor2[j].setOpaque(true);
									Search_GUI.jl_flavor2[j].setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
									Search_GUI.jl_flavor2[j].setBackground(Color.DARK_GRAY);
									Search_GUI.jl_flavor2[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor2[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("spicy")) {
									Search_GUI.jl_flavor3[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor3[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor3[j].setOpaque(true);
									Search_GUI.jl_flavor3[j].setBorder(BorderFactory.createLineBorder(Color.red));
									Search_GUI.jl_flavor3[j].setBackground(Color.red);
									Search_GUI.jl_flavor3[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor3[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("sour")) {
									Search_GUI.jl_flavor4[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor4[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor4[j].setOpaque(true);
									Search_GUI.jl_flavor4[j].setBorder(BorderFactory.createLineBorder(Color.orange));
									Search_GUI.jl_flavor4[j].setBackground(Color.orange);
									Search_GUI.jl_flavor4[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor4[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								}
								Search_GUI.box_recipe[j].add(Search_GUI.box_flavor[j]);
							}
							Search_GUI.box_flavor[j].add(Box.createHorizontalGlue());
						} catch (ClassNotFoundException | SQLException e1) {
							e1.printStackTrace();
						}

						Search_GUI.box_box[j].add(Search_GUI.box_recipe[j]);
						Search_GUI.box_box[j].add(Box.createHorizontalGlue());
						Search_GUI.innerPanel[j].add(Search_GUI.box_box[j]);
						Search_GUI.innerPanel[j].add(Box.createHorizontalGlue());
						Search_GUI.box_bottomHoriBox[j].add(Search_GUI.innerPanel[j]);
						Search_GUI.box_bottomHoriBox[j].add(Box.createHorizontalGlue());
					}

					if (j % 2 == 1) {

						Search_GUI.innerPanel[j].setBorder(BorderFactory.createLineBorder(Color.gray));

						Search_GUI.jl_name[j].setText(targetRecipe.get(j).getDishName());
						Search_GUI.jl_name[j].setFont(new Font("Arial", Font.BOLD, (int) (width * 0.01317716)));
						Search_GUI.jl_name[j].setForeground(Color.black);
						Search_GUI.box_name[j].add(Search_GUI.jl_name[j]);
						Search_GUI.box_name[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_name[j]);

						Search_GUI.jl_prepTime[j].setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_prepTime[j].setForeground(Color.black);
						Search_GUI.box_prepTime[j].add(Search_GUI.jl_prepTime[j]);
						Search_GUI.jl_targetPrepTime[j].setText(targetRecipe.get(j).getPreparationTime() + "min");
						Search_GUI.jl_targetPrepTime[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetPrepTime[j].setForeground(Color.black);
						Search_GUI.box_prepTime[j].add(Search_GUI.jl_targetPrepTime[j]);
						Search_GUI.box_prepTime[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_prepTime[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						Search_GUI.jl_cookTime[j].setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_cookTime[j].setForeground(Color.black);
						Search_GUI.box_cookTime[j].add(Search_GUI.jl_cookTime[j]);
						Search_GUI.jl_targetCookTime[j].setText(targetRecipe.get(j).getCookingTime() + "min");
						Search_GUI.jl_targetCookTime[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetCookTime[j].setForeground(Color.black);
						Search_GUI.box_cookTime[j].add(Search_GUI.jl_targetCookTime[j]);
						Search_GUI.box_cookTime[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_cookTime[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						Search_GUI.jl_ingredients[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_ingredients[j].setForeground(Color.black);
						Search_GUI.box_ingredients[j].add(Search_GUI.jl_ingredients[j]);
						try {
							Search_GUI.jl_targetIngredients[j]
									.setText(cookBook.getAllIngredientsName(targetRecipe.get(j).getDishName()));
						} catch (ClassNotFoundException | SQLException e1) {
							e1.printStackTrace();
						}
						Search_GUI.jl_targetIngredients[j]
								.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.008784773)));
						Search_GUI.jl_targetIngredients[j].setForeground(Color.black);
						Search_GUI.box_ingredients[j].add(Search_GUI.jl_targetIngredients[j]);
						Search_GUI.box_ingredients[j].add(Box.createHorizontalGlue());
						Search_GUI.box_recipe[j].add(Search_GUI.box_ingredients[j]);
						Search_GUI.box_recipe[j].add(Box.createVerticalStrut((int) (height * 0.013)));

						try {
							for (int i = 0; i < cookBook.getAllTags(targetRecipe.get(j).getDishName()).size(); i++) {
								String targetTag = cookBook.getAllTags(targetRecipe.get(j).getDishName()).get(i);
								if (targetTag.equals("sweet")) {
									Search_GUI.jl_flavor1[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor1[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor1[j].setOpaque(true);
									Search_GUI.jl_flavor1[j].setBorder(BorderFactory.createLineBorder(Color.green));
									Search_GUI.jl_flavor1[j].setBackground(Color.green);
									Search_GUI.jl_flavor1[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor1[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("salty")) {
									Search_GUI.jl_flavor2[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor2[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor2[j].setOpaque(true);
									Search_GUI.jl_flavor2[j].setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
									Search_GUI.jl_flavor2[j].setBackground(Color.DARK_GRAY);
									Search_GUI.jl_flavor2[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor2[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("spicy")) {
									Search_GUI.jl_flavor3[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor3[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor3[j].setOpaque(true);
									Search_GUI.jl_flavor3[j].setBorder(BorderFactory.createLineBorder(Color.red));
									Search_GUI.jl_flavor3[j].setBackground(Color.red);
									Search_GUI.jl_flavor3[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor3[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								} else if (targetTag.equals("sour")) {
									Search_GUI.jl_flavor4[j].setHorizontalAlignment(JLabel.CENTER);
									Search_GUI.jl_flavor4[j]
											.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.008784773)));
									Search_GUI.jl_flavor4[j].setOpaque(true);
									Search_GUI.jl_flavor4[j].setBorder(BorderFactory.createLineBorder(Color.orange));
									Search_GUI.jl_flavor4[j].setBackground(Color.orange);
									Search_GUI.jl_flavor4[j].setForeground(Color.white);
									Search_GUI.box_flavor[j].add(Search_GUI.jl_flavor4[j]);
									Search_GUI.box_flavor[j].add(Box.createHorizontalStrut((int) (height * 0.013)));
								}
								Search_GUI.box_recipe[j].add(Search_GUI.box_flavor[j]);
							}
							Search_GUI.box_flavor[j].add(Box.createHorizontalGlue());
						} catch (ClassNotFoundException | SQLException e5) {
							e5.printStackTrace();
						}

						Search_GUI.box_box[j].add(Search_GUI.box_recipe[j]);
						Search_GUI.box_box[j].add(Box.createHorizontalGlue());
						Search_GUI.innerPanel[j].add(Search_GUI.box_box[j]);
						Search_GUI.innerPanel[j].add(Box.createHorizontalGlue());
						Search_GUI.box_bottomHoriBox[j - 1].add(Box.createHorizontalStrut((int) (width * 0.058565)));
						Search_GUI.box_bottomHoriBox[j - 1].add(Search_GUI.innerPanel[j]);

					}

					if (j % 2 == 0) {
						Search_GUI.box_bottomPanelItem.add(Search_GUI.box_bottomHoriBox[j]);
					} else {
						Search_GUI.box_bottomPanelItem.add(Search_GUI.box_bottomHoriBox[j - 1]);
						Search_GUI.box_bottomPanelItem.add(Box.createVerticalStrut((int) (height * 0.026)));
					}
				}
				Search_GUI.bottomPanel.add(Search_GUI.box_bottomPanelItem);
				search_GUI.revalidate();
			}
		}
	}

	/**
	 * CLosing the Search_GUI and opening the Create_GUI
	 */

	class Listener_Search_SearchAdd implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			search_GUI.dispose();
			create_GUI.showGUI();
		}
	}

	/**
	 * Deleting the default text automatically when starting to type
	 */

	class Listener_Search_SearchKey implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {
			Search_GUI.jtf_search.setForeground(Color.BLACK);
			if (Search_GUI.jtf_search.getText().equals("Dish Name/Ingredient")) {
				Search_GUI.jtf_search.setText("");
			}
		}

		@Override
		public void keyPressed(KeyEvent e) {
		}

		@Override
		public void keyReleased(KeyEvent e) {
		}
	}

	/**
	 * Deleting the default text automatically when clicking on the text field
	 */

	class Listener_Search_SearchMouse implements MouseListener {
		public void mousePressed(MouseEvent e) {
			if (Search_GUI.jtf_search.getText().equals("Dish Name/Ingredient")) {
				Search_GUI.jtf_search.setText("");
			}
		}

		@Override
		public void mouseClicked(MouseEvent e) {
		}

		@Override
		public void mouseReleased(MouseEvent e) {
		}

		@Override
		public void mouseEntered(MouseEvent e) {
		}

		@Override
		public void mouseExited(MouseEvent e) {
		}
	}

	/**
	 * Deleting steps in Edit_GUI
	 */

	class Listener_Edit_DeleteStep implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int number = 0;
			if (Edit_GUI.panel_3.getComponents().length == 1) {
				JOptionPane.showMessageDialog(null, "You cannot delete this!");
			} else {

				number = Edit_GUI.stepList.size();
				Edit_GUI.stepList.removeLast();
				Edit_GUI.panel_3.remove(Edit_GUI.panel_3.getComponent(number-1));
				Edit_GUI.countStepText = Edit_GUI.countStepText - 1;

			}
			edit_GUI.frame.revalidate();

		}
	}

	/**
	 * Adding a new blank step text in Edit_GUI
	 */

	class Listener_Edit_AddStep implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Edit_GUI.box = Box.createHorizontalBox();
			Edit_GUI.tfield = new JTextField();
			Edit_GUI.countStepText++;
			Edit_GUI.tfield.setColumns(10);
			Edit_GUI.tfield.setMaximumSize(new Dimension(4000, 30));
			Edit_GUI.tfield.setFont(new Font("SansSerif",Font.PLAIN,24));
			Edit_GUI.panel_3.add(Edit_GUI.box);
			Edit_GUI.box.add(Edit_GUI.tfield);
			Edit_GUI.stepList.add(Edit_GUI.tfield);
			edit_GUI.frame.revalidate();
		}
	}

	/**
	 * Deleting the ingredients in Edit_GUI
	 */

	class Listener_Edit_DeleteIngredient implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int number=0;
			if (Edit_GUI.panel_2.getComponents().length == 2) {

				JOptionPane.showMessageDialog(null, "You cannot delete this!");

			} else {

				number = Edit_GUI.ingredientBoxList.size();
				Edit_GUI.ingredientBoxList.removeLast();
				Edit_GUI.panel_2.remove(Edit_GUI.panel_2.getComponent(number));
				Edit_GUI.countIngredientText = Edit_GUI.countIngredientText - 4;
				edit_GUI.frame.revalidate();

			}
		}
	}

	/**
	 * Adding a new row of blank ingredient text area
	 */

	class Listener_Edit_AddIngredient implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			Edit_GUI.box = Box.createHorizontalBox();
			Edit_GUI.ingredientBoxList.add(Edit_GUI.box);
			Edit_GUI.panel_2.add(Edit_GUI.box);

			for (int i = 1; i <= 4; i++) {
				
				Edit_GUI.tfield = new JTextField();
				Edit_GUI.tfield.setColumns(10);
				Edit_GUI.tfield.setMaximumSize(new Dimension(1000, 30));
				Edit_GUI.tfield.setFont(new Font("SansSerif", Font.PLAIN, 24));
				Edit_GUI.box.add(Edit_GUI.tfield);
				Edit_GUI.ingredientTextField.add(Edit_GUI.tfield);
				Edit_GUI.countIngredientText = Edit_GUI.countIngredientText + 1;
				edit_GUI.frame.revalidate();
				
			}
		}
	}

	/**
	 * Saving the new data to cook book after checking whether all the
	 * information is correctly filled in
	 */

	class Listener_Edit_Save implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			Integer recipeId = null;
			String dishName = null;
			String location = null;
			Integer servings;
			String preparationTime = null;
			String cookingTime = null;

			recipeId = Edit_GUI.targetRecipe.getRecipeId();

			try {
				dishName = Edit_GUI.targetRecipe.getDishName();
				exception.checkRecipeName(dishName);
			} catch (InputException e1) {
				e1.printStackTrace();
			}

			location = Edit_GUI.textField_2.getText();
			servings = Edit_GUI.comboBox.getSelectedIndex() + 1;

			try {
				preparationTime = Edit_GUI.textField_3.getText();
				cookingTime = Edit_GUI.textField_4.getText();
				exception.checkPrepTime(preparationTime);
				exception.checkCookTime(cookingTime);
			} catch (InputException e1) {
				e1.printStackTrace();
			}

			if (Edit_GUI.countIngredientText == 20) {

			} else {

				int counter = (Edit_GUI.countIngredientText - 20) / 4;

				for (int n = 0; n < counter; n++) {
					try {
						exception.checkIngredientName(Edit_GUI.ingredientTextField.get((n) * 4).getText());
						exception.checkIngredientQuantity(Edit_GUI.ingredientTextField.get(1 + (n) * 4).getText());
						exception.checkIngredientUnit(Edit_GUI.ingredientTextField.get(2 + (n) * 4).getText());
					} catch (InputException e2) {
						e2.printStackTrace();
					}
				}
			}

			try {
				
				exception.checkRecipe();
				Edit_GUI.targetRecipe = new Recipe(recipeId, dishName, location, servings);
				Edit_GUI.targetRecipe.setPreparationTime(Integer.parseInt(preparationTime));
				Edit_GUI.targetRecipe.setCookingTime(Integer.parseInt(cookingTime));
				
				try {
					cookBook.updateRecipe(Edit_GUI.targetRecipe);
				} catch (ClassNotFoundException | SQLException e2) {
					e2.printStackTrace();
				}

				try {
					cookBook.removeAllTag(Edit_GUI.targetRecipe);
				} catch (ClassNotFoundException | SQLException e2) {
					e2.printStackTrace();
				}
				if (Edit_GUI.chckbxSpicy.isSelected()) {
					Edit_GUI.targetRecipe.addTag(new Tag(Edit_GUI.chckbxSpicy.getText()));
				}
				if (Edit_GUI.chckbxSweet.isSelected()) {
					Edit_GUI.targetRecipe.addTag(new Tag(Edit_GUI.chckbxSweet.getText()));
				}
				if (Edit_GUI.chckbxSalty.isSelected()) {
					Edit_GUI.targetRecipe.addTag(new Tag(Edit_GUI.chckbxSalty.getText()));
				}
				if (Edit_GUI.chckbxSour.isSelected()) {
					Edit_GUI.targetRecipe.addTag(new Tag(Edit_GUI.chckbxSour.getText()));
				}

				try {
					cookBook.removeAllIngredients(Edit_GUI.targetRecipe);
					cookBook.removeAllSteps(Edit_GUI.targetRecipe);
				} catch (ClassNotFoundException | SQLException e2) {
					e2.printStackTrace();
				}

				if ((Edit_GUI.countIngredientText) == 20) {

				} else {

					int counter = (Edit_GUI.countIngredientText - 20) / 4;

					for (int n = 0; n < counter; n++) {
						if (Edit_GUI.ingredientTextField.get(3 + (n) * 4).getText().equals("")) {

							try {
								Edit_GUI.targetRecipe.addIngredient(
										new Ingredient(Edit_GUI.ingredientTextField.get((n) * 4).getText(),
												Double.parseDouble(
														Edit_GUI.ingredientTextField.get(1 + (n) * 4).getText()),
												Edit_GUI.ingredientTextField.get(2 + (n) * 4).getText()));
							} catch (NumberFormatException | ClassNotFoundException | SQLException e1) {
								e1.printStackTrace();
							}

						} else {

							try {
								Edit_GUI.targetRecipe.addIngredient(
										new Ingredient(Edit_GUI.ingredientTextField.get((n) * 4).getText(),
												Double.parseDouble(
														Edit_GUI.ingredientTextField.get(1 + (n) * 4).getText()),
												Edit_GUI.ingredientTextField.get(2 + (n) * 4).getText(),
												Edit_GUI.ingredientTextField.get(3 + (n) * 4).getText()));
							} catch (NumberFormatException | ClassNotFoundException | SQLException e1) {
								e1.printStackTrace();
							}
						}

					}

				}

				if (Edit_GUI.countStepText == 100) {

				} else {
					int counter = Edit_GUI.countStepText - 100;

					for (int n = 0; n < counter; n++) {
						
						String str = cookBook.replaceSingleQuote(Edit_GUI.stepList.get(n).getText());
						Edit_GUI.targetRecipe.addPreparationStep(str);
					}
				}
				try {
					
					cookBook.addRecipeTag(Edit_GUI.targetRecipe);
					cookBook.updateIngredient(Edit_GUI.targetRecipe);
					cookBook.addRecipeIngredient(Edit_GUI.targetRecipe);
					cookBook.addPreparationStep(Edit_GUI.targetRecipe);

				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}

			} catch (InputException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * Going back from Edit_GUI to View_GUI
	 */

	class Listener_Edit_Back implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			Edit_GUI.frame.dispose();
			View_GUI.recipeName = Edit_GUI.textField_1.getText();
			view_GUI.showGUI();
			ShowView();
			try {
				rebuild_View_GUI();
			} catch (ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * Closing the deletion confirmation window
	 */

	class Listener_Delete_Cancel implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			DeleteWindow.frame.dispose();
		}
	}

	/**
	 * Deleting the recipe in cook book, closing the current View_GUI and
	 * returning to Search_GUI
	 */

	class Listener_Delete_Confirm implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			try {
				
				DeleteWindow.dishName = View_GUI.recipeName;
				int id = cookBook.selectIdByName(DeleteWindow.dishName);
				cookBook.deleteRecipe(id);
				JOptionPane.showMessageDialog(null, "Successfully deleted!");
				DeleteWindow.frame.dispose();
				View_GUI.frame.dispose();
				search_GUI.showGUI();

			} catch (ClassNotFoundException | SQLException e6) {
				e6.printStackTrace();
			}
		}
	}

	/**
	 * Going back from Create_GUI to Search_GUI
	 */

	class Listener_Create_Back implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			Create_GUI.frame.dispose();
			search_GUI.showGUI();
		}
	}

	/**
	 * Saving the created recipe to cook book after checking whether all the
	 * information is correctly filled in
	 */

	class Listener_Create_Save implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			Integer recipeId = null;
			String dishName = null;
			String location;
			Integer servings;
			Integer preparationTime;
			Integer cookingTime;
			int counter = 0;

			try {
				recipeId = cookBook.getRecipeId();
			} catch (ClassNotFoundException | SQLException e1) {

				e1.printStackTrace();
			}

			try {
				dishName = Create_GUI.textField_1.getText();

				exception.checkRecipeName(dishName);

			} catch (InputException E) {
				E.printStackTrace();
			}

			try {
				if (cookBook.checkSameName(dishName)) {
					location = Create_GUI.textField_2.getText();
					servings = Create_GUI.comboBox.getSelectedIndex() + 1;

					preparationTime = Integer.parseInt(Create_GUI.textField_3.getText());
					cookingTime = Integer.parseInt(Create_GUI.textField_4.getText());

					try {
						exception.checkIngredientName(Create_GUI.textField_5.getText());
						exception.checkIngredientQuantity(Create_GUI.textField_6.getText());
						exception.checkIngredientUnit(Create_GUI.textField_7.getText());
					} catch (InputException e2) {

						e2.printStackTrace();
					}

					if (Create_GUI.countIngredientText == 20) {
					} else {
						counter = (Create_GUI.countIngredientText - 20) / 4;

						for (int n = 0; n < counter; n++) {
							try {
								exception.checkIngredientName(Create_GUI.ingredientTextField.get((n) * 4).getText());
								exception.checkIngredientQuantity(
										Create_GUI.ingredientTextField.get(1 + (n) * 4).getText());
								exception
										.checkIngredientUnit(Create_GUI.ingredientTextField.get(2 + (n) * 4).getText());
							} catch (InputException e1) {

								e1.printStackTrace();
							}
						}
					}

					try {
						exception.checkRecipe();
						Recipe recipe2 = new Recipe(recipeId, dishName, location, servings);
						recipe2.setPreparationTime(preparationTime);
						recipe2.setCookingTime(cookingTime);
						if (Create_GUI.chckbxSpicy.isSelected()) {
							recipe2.addTag(new Tag(Create_GUI.chckbxSpicy.getText()));
						}
						if (Create_GUI.chckbxSweet.isSelected()) {
							recipe2.addTag(new Tag(Create_GUI.chckbxSweet.getText()));
						}
						if (Create_GUI.chckbxSalty.isSelected()) {
							recipe2.addTag(new Tag(Create_GUI.chckbxSalty.getText()));
						}
						if (Create_GUI.chckbxSour.isSelected()) {
							recipe2.addTag(new Tag(Create_GUI.chckbxSour.getText()));
						}

						try {
							recipe2.addIngredient(new Ingredient(Create_GUI.textField_5.getText(),
									Double.parseDouble(Create_GUI.textField_6.getText()),
									Create_GUI.textField_7.getText(), Create_GUI.textField_8.getText()));
						} catch (NumberFormatException | ClassNotFoundException | SQLException e1) {

							e1.printStackTrace();
						}

						for (int n = 0; n < counter; n++) {
							if (Create_GUI.ingredientTextField.get(3 + (n) * 4).getText().equals("")) {
								try {
									recipe2.addIngredient(
											new Ingredient(Create_GUI.ingredientTextField.get((n) * 4).getText(),
													Integer.parseInt(
															Create_GUI.ingredientTextField.get(1 + (n) * 4).getText()),
													Create_GUI.ingredientTextField.get(2 + (n) * 4).getText()));
								} catch (NumberFormatException | ClassNotFoundException | SQLException e1) {

									e1.printStackTrace();
								}
							} else {
								try {
									recipe2.addIngredient(
											new Ingredient(Create_GUI.ingredientTextField.get((n) * 4).getText(),
													Integer.parseInt(
															Create_GUI.ingredientTextField.get(1 + (n) * 4).getText()),
													Create_GUI.ingredientTextField.get(2 + (n) * 4).getText(),
													Create_GUI.ingredientTextField.get(3 + (n) * 4).getText()));
								} catch (NumberFormatException | ClassNotFoundException | SQLException e1) {

									e1.printStackTrace();
								}
							}
						}

						recipe2.addPreparationStep(Create_GUI.textField_9.getText());
						if (Create_GUI.countStepText == 100) {
						} else {
							int counter1 = Create_GUI.countStepText - 100;
							for (int n = 0; n < counter1; n++) {
								recipe2.addPreparationStep(Create_GUI.stepList.get(n).getText());
							}
						}

						try {
							cookBook.returnRecipe(recipe2);
						} catch (SQLException e1) {

							e1.printStackTrace();
						}

					} catch (InputException e2) {

						e2.printStackTrace();
					}

				} else {
					JOptionPane.showMessageDialog(null, "Duplicate recipe name, try annother one!");
				}

			} catch (ClassNotFoundException e3) {
				e3.printStackTrace();
			} catch (SQLException e3) {
				e3.printStackTrace();
			}
			create_GUI.revalidate();
			Create_GUI.frame.dispose();
			search_GUI.showGUI();

		}
	}

	/**
	 * Adding a new blank step text in Create_GUI
	 */

	class Listener_Create_AddStep implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			Create_GUI.box = Box.createHorizontalBox();
			Create_GUI.tfield = new JTextField();
			Create_GUI.countStepText++;
			Create_GUI.tfield.setColumns(10);
			Create_GUI.tfield.setMaximumSize(new Dimension(2000, 30));
			Create_GUI.tfield.setFont(new Font("SansSerif", Font.PLAIN, 24));
			Create_GUI.panel_3.add(Create_GUI.box);
			Create_GUI.box.add(Create_GUI.tfield);
			Create_GUI.stepList.add(Create_GUI.tfield);
			create_GUI.frame.revalidate();
			
		}

	}

	/**
	 * Deleting steps in Create_GUI
	 */

	class Listener_Create_DeleteStep implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			if (Create_GUI.panel_3.getComponents().length == 1) {
				JOptionPane.showMessageDialog(null, "You cannot delete this!");
			} else {

				int number = Create_GUI.stepList.size();
				Create_GUI.stepList.removeLast();
				Create_GUI.panel_3.remove(Create_GUI.panel_3.getComponent(number));
				Create_GUI.countStepText = Create_GUI.countStepText - 1;

			}
			create_GUI.frame.revalidate();
		}
	}

	/**
	 * Adding a new row of blank ingredient text area
	 */

	class Listener_Create_AddIngredient implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			Create_GUI.box = Box.createHorizontalBox();
			Create_GUI.box.setAlignmentX(Component.LEFT_ALIGNMENT);
			Create_GUI.ingredientBoxList.add(Create_GUI.box);
			Create_GUI.panel_2.add(Create_GUI.box);
			
			for (int i = 1; i <= 4; i++) {
				
				Create_GUI.tfield = new JTextField();
				Create_GUI.tfield.setColumns(10);
				Create_GUI.tfield.setMaximumSize(new Dimension(800, 30));
				Create_GUI.tfield.setFont(new Font("SansSerif", Font.PLAIN, 24));
				Create_GUI.box.add(Create_GUI.tfield);
				Create_GUI.ingredientTextField.add(Create_GUI.tfield);
				Create_GUI.countIngredientText = Create_GUI.countIngredientText + 1;
			}
			create_GUI.frame.revalidate();
		}
	}

	/**
	 * Deleting the ingredients in Edit_GUI
	 */

	class Listener_Create_DeleteIngredient implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			if (Create_GUI.panel_2.getComponents().length == 2) {
				JOptionPane.showMessageDialog(null, "You cannot delete this!");
			} else {
				int number = Create_GUI.ingredientBoxList.size();
				Create_GUI.ingredientBoxList.removeLast();
				Create_GUI.panel_2.remove(Create_GUI.panel_2.getComponent(number + 1));
				Create_GUI.countIngredientText = Create_GUI.countIngredientText - 4;
				for (int i = 0; i < 4; i++) {
					Create_GUI.ingredientTextField.removeLast();
				}
				create_GUI.frame.revalidate();
			}
		}
	}

	/**
	 * The decoration of View_GUI
	 */

	public void ShowView() {

		Recipe recipe;
		try {

			recipe = cookBook.catchRecipe(View_GUI.recipeName);

			View_GUI.dishName.setText(View_GUI.recipeName);
			View_GUI.dishName.setFont(new Font("SansSerif", Font.PLAIN, 36));
			View_GUI.dishName.setForeground(Color.BLACK);

			JLabel location = new JLabel();
			location.setText(recipe.getLocation());
			location.setFont(new Font("SansSerif",Font.PLAIN,36));
			View_GUI.locationPanel.add(location);
			try {
				View_GUI.flavorPanel.removeAll();
			} catch (Exception e) {
				e.printStackTrace();
			}

			for (int i = 0; i < recipe.getTagList().size(); i++) {

				JLabel label = new JLabel();
				label.setFont(new Font("SansSerif", Font.PLAIN, 24));
				label.setText(recipe.getTagList().get(i).getTagContent());

				if (recipe.getTagList().get(i).getTagContent() == "sweet") {

					label.setFont(new Font("SansSerif", Font.PLAIN, 24));
					label.setOpaque(true);
					label.setBorder(BorderFactory.createLineBorder(Color.green));
					label.setForeground(Color.white);
					label.setBackground(Color.green);

				}
				if (recipe.getTagList().get(i).getTagContent() == "salty") {

					label.setOpaque(true);
					label.setBorder(BorderFactory.createLineBorder(Color.green));
					label.setForeground(Color.white);
					label.setBackground(Color.green);

				}
				if (recipe.getTagList().get(i).getTagContent() == "spicy") {

					label.setOpaque(true);
					label.setBorder(BorderFactory.createLineBorder(Color.green));
					label.setForeground(Color.white);
					label.setBackground(Color.green);

				}
				if (recipe.getTagList().get(i).getTagContent() == "sour") {

					label.setOpaque(true);
					label.setBorder(BorderFactory.createLineBorder(Color.green));
					label.setForeground(Color.white);
					label.setBackground(Color.green);

				}
				View_GUI.flavorPanel.add(label);
				View_GUI.flavorPanel.add(Box.createHorizontalStrut(15));

			}

			View_GUI.servingComboBox.setSelectedIndex(recipe.getServings() - 1);
			View_GUI.prepareTimeLabel = new JLabel();

			JLabel min = new JLabel("min");

			min.setFont(new Font("SansSerif", Font.PLAIN, 16));

			View_GUI.prepareTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
			View_GUI.prepareTimeLabel.setText(Integer.toString(recipe.getPreparationTime()));
			View_GUI.prepareTimePanel.add(View_GUI.prepareTimeLabel);
			View_GUI.prepareTimePanel.add(Box.createHorizontalStrut(10));
			View_GUI.prepareTimePanel.add(min);

			JLabel cookTimeLabel = new JLabel();

			cookTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
			cookTimeLabel.setText(Integer.toString(recipe.getCookingTime()));

			View_GUI.cookTimePanel.add(cookTimeLabel);

			JLabel min2 = new JLabel("min");
			min2.setFont(new Font("SansSerif", Font.PLAIN, 16));

			View_GUI.cookTimePanel.add(Box.createHorizontalStrut(10));
			View_GUI.cookTimePanel.add(min2);

			for (int i = 0; i < recipe.getIngredient().size(); i++) {

				JLabel label = new JLabel();
				label.setFont(new Font("SansSerif", Font.PLAIN, 16));
				label.setText(cookBook.getInsideIngredientSentence(recipe, i));

				View_GUI.ingredientsPanel.add(label);
				View_GUI.ingredientsPanel.add(Box.createVerticalStrut(10));

			}

			for (int i = 0; i < recipe.getSteps().size(); i++) {

				JLabel label = new JLabel();
				label.setFont(new Font("SansSerif", Font.PLAIN, 16));
				label.setText(cookBook.getStepSentence(recipe.getDishName(), i));

				View_GUI.stepsPanel.add(label);
				View_GUI.stepsPanel.add(Box.createVerticalStrut(10));

			}

			View_GUI.frame.setVisible(true);
			View_GUI.counter++;

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		} catch (SQLException e) {

			e.printStackTrace();

		}

	}

	/**
	 * Refreshing the View_GUI when changing the serving number
	 */

	class Listener_View_Refresh implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {

				int changedServing = View_GUI.servingComboBox.getSelectedIndex() + 1;

				Recipe recipe;

				recipe = cookBook.catchRecipe(View_GUI.recipeName);
				recipe.reviseServings(changedServing);

				View_GUI.prepareTimePanel.removeAll();

				JLabel prepareTimeLabel1 = new JLabel("Preparing time:");
				prepareTimeLabel1.setFont(new Font("SansSerif", Font.PLAIN, 23));
				prepareTimeLabel1.setAlignmentX(Component.LEFT_ALIGNMENT);

				JLabel min = new JLabel("min");
				min.setFont(new Font("SansSerif", Font.PLAIN, 20));

				JLabel prepareTimeLabel = new JLabel();
				prepareTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 20));
				prepareTimeLabel.setText(Integer.toString(recipe.getPreparationTime()));

				View_GUI.prepareTimePanel.setLayout(new BoxLayout(View_GUI.prepareTimePanel, BoxLayout.X_AXIS));
				View_GUI.prepareTimePanel.add(prepareTimeLabel1);
				View_GUI.prepareTimePanel.add(Box.createHorizontalStrut(36));
				View_GUI.prepareTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

				View_GUI.prepareTimePanel.add(prepareTimeLabel);
				View_GUI.prepareTimePanel.add(Box.createHorizontalStrut(10));
				View_GUI.prepareTimePanel.add(min);

				View_GUI.cookTimePanel.removeAll();

				JLabel cookTimeLabel = new JLabel("Cooking time:");
				cookTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 23));
				cookTimeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

				View_GUI.cookTimePanel.setLayout(new BoxLayout(View_GUI.cookTimePanel, BoxLayout.X_AXIS));
				View_GUI.cookTimePanel.add(cookTimeLabel);
				View_GUI.cookTimePanel.add(Box.createHorizontalStrut(50));
				View_GUI.cookTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

				JLabel cookTimeLabel1 = new JLabel();
				cookTimeLabel1.setFont(new Font("SansSerif", Font.PLAIN, 20));
				cookTimeLabel1.setText(Integer.toString(recipe.getCookingTime()));

				View_GUI.cookTimePanel.add(cookTimeLabel1);

				JLabel min2 = new JLabel("min");
				min2.setFont(new Font("SansSerif", Font.PLAIN, 20));

				View_GUI.cookTimePanel.add(Box.createHorizontalStrut(10));
				View_GUI.cookTimePanel.add(min2);

				View_GUI.ingredientPanel.removeAll();
				View_GUI.ingredientsPanel.removeAll();

				JLabel ingredientLabel = new JLabel("Ingredients:");
				ingredientLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));
				ingredientLabel.setAlignmentY(Component.TOP_ALIGNMENT);
				ingredientLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

				View_GUI.ingredientPanel.setLayout(new BoxLayout(View_GUI.ingredientPanel, BoxLayout.X_AXIS));
				View_GUI.ingredientsPanel.setAlignmentY(Component.TOP_ALIGNMENT);
				View_GUI.ingredientsPanel.setLayout(new BoxLayout(View_GUI.ingredientsPanel, BoxLayout.Y_AXIS));
				View_GUI.ingredientPanel.add(ingredientLabel);
				View_GUI.ingredientPanel.add(Box.createHorizontalStrut(65));
				View_GUI.ingredientPanel.add(View_GUI.ingredientsPanel);
				View_GUI.ingredientPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

				for (int i = 0; i < recipe.getIngredient().size(); i++) {

					JLabel label = new JLabel();
					label.setFont(new Font("SansSerif", Font.PLAIN, 20));
					label.setText(cookBook.getInsideIngredientSentence(recipe, i));

					View_GUI.ingredientsPanel.add(label);
					View_GUI.ingredientsPanel.add(Box.createVerticalStrut(10));

				}

				View_GUI.frame.revalidate();

			} catch (ClassNotFoundException e1) {

				e1.printStackTrace();

			} catch (SQLException e1) {

				e1.printStackTrace();

			}
		}
	}

	/**
	 * Demonstrating the deletion window
	 */

	class Listener_View_Delete implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			deleteWindow.showGUI();
		}
	}

	/**
	 * Skipping to the Edit_GUI when clicking the Edit button
	 */

	class Listener_View_Edit implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			View_GUI.frame.dispose();
			Edit_GUI.recipeName = View_GUI.dishName.getText();
			edit_GUI.showGUI();
			viewToEdit();
		}
	}

	/**
	 * Going back from View_GUI to Search_GUI
	 */

	class Listener_View_Back implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			View_GUI.frame.setVisible(false);
			search_GUI.showGUI();

		}
	}

	/**
	 * Rebuilding the View_GUI
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void rebuild_View_GUI() throws ClassNotFoundException, SQLException {

		int changedServing = View_GUI.servingComboBox.getSelectedIndex() + 1;

		Recipe recipe;
		int id = cookBook.selectIdByName(View_GUI.recipeName);
		String dish = cookBook.selectDishnameById(id);
		recipe = cookBook.catchRecipe(dish);

		recipe.reviseServings(changedServing);

		View_GUI.prepareTimePanel.removeAll();
		View_GUI.cookTimePanel.removeAll();
		View_GUI.ingredientPanel.removeAll();
		View_GUI.stepsPanel.removeAll();
		View_GUI.flavorPanel.removeAll();
		View_GUI.locationPanel.removeAll();
		View_GUI.ingredientsPanel.removeAll();
		View_GUI.stepPanel.removeAll();

		View_GUI.locationPanel.setLayout(new BoxLayout(View_GUI.locationPanel, BoxLayout.X_AXIS));

		JLabel locationLabel = new JLabel("Location:");
		locationLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));

		View_GUI.locationPanel.add(locationLabel);
		View_GUI.locationPanel.add(Box.createHorizontalStrut(90));
		View_GUI.locationPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		JLabel location = new JLabel();
		location.setFont(new Font("SansSerif", Font.PLAIN, 20));
		location.setText(recipe.getLocation());

		View_GUI.locationPanel.add(location);

		JLabel flavorLabel = new JLabel("Flavors:");
		flavorLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));

		View_GUI.flavorPanel.setLayout(new BoxLayout(View_GUI.flavorPanel, BoxLayout.X_AXIS));
		View_GUI.flavorPanel.add(flavorLabel);
		View_GUI.flavorPanel.add(Box.createHorizontalStrut(100));
		View_GUI.flavorPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		for (int i = 0; i < recipe.getTagList().size(); i++) {

			JLabel label = new JLabel();

			label.setFont(new Font("SansSerif", Font.PLAIN, 20));
			label.setText(recipe.getTagList().get(i).getTagContent());

			if (recipe.getTagList().get(i).getTagContent().equals("sweet")) {

				label.setOpaque(true);
				label.setBorder(BorderFactory.createLineBorder(Color.green));
				label.setForeground(Color.white);
				label.setBackground(Color.green);

			}
			if (recipe.getTagList().get(i).getTagContent().equals("salty")) {

				label.setOpaque(true);
				label.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
				label.setForeground(Color.white);
				label.setBackground(Color.DARK_GRAY);

			}
			if (recipe.getTagList().get(i).getTagContent().equals("spicy")) {

				label.setOpaque(true);
				label.setBorder(BorderFactory.createLineBorder(Color.red));
				label.setForeground(Color.white);
				label.setBackground(Color.red);

			}
			if (recipe.getTagList().get(i).getTagContent().equals("sour")) {

				label.setOpaque(true);
				label.setBorder(BorderFactory.createLineBorder(Color.orange));
				label.setForeground(Color.white);
				label.setBackground(Color.orange);

			}

			View_GUI.flavorPanel.add(label);
			View_GUI.flavorPanel.add(Box.createHorizontalStrut(15));

		}

		JLabel prepareTimeLabel1 = new JLabel("Preparing time:");
		prepareTimeLabel1.setFont(new Font("SansSerif", Font.PLAIN, 23));

		JLabel min = new JLabel("min");
		min.setFont(new Font("SansSerif", Font.PLAIN, 20));

		JLabel prepareTimeLabel = new JLabel();
		prepareTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 20));
		prepareTimeLabel1.setAlignmentX(Component.LEFT_ALIGNMENT);

		View_GUI.prepareTimePanel.setLayout(new BoxLayout(View_GUI.prepareTimePanel, BoxLayout.X_AXIS));
		View_GUI.prepareTimePanel.add(prepareTimeLabel1);
		View_GUI.prepareTimePanel.add(Box.createHorizontalStrut(36));
		View_GUI.prepareTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		prepareTimeLabel.setText(Integer.toString(recipe.getPreparationTime()));
		View_GUI.prepareTimePanel.add(prepareTimeLabel);
		View_GUI.prepareTimePanel.add(Box.createHorizontalStrut(10));
		View_GUI.prepareTimePanel.add(min);

		JLabel cookTimeLabel = new JLabel("Cooking time:");
		cookTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 23));
		cookTimeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		View_GUI.cookTimePanel.setLayout(new BoxLayout(View_GUI.cookTimePanel, BoxLayout.X_AXIS));
		View_GUI.cookTimePanel.add(cookTimeLabel);
		View_GUI.cookTimePanel.add(Box.createHorizontalStrut(50));
		View_GUI.cookTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		JLabel cookTimeLabel1 = new JLabel();
		cookTimeLabel1.setFont(new Font("SansSerif", Font.PLAIN, 20));
		cookTimeLabel1.setText(Integer.toString(recipe.getCookingTime()));
		View_GUI.cookTimePanel.add(cookTimeLabel1);

		JLabel min2 = new JLabel("min");
		min2.setFont(new Font("SansSerif", Font.PLAIN, 20));
		View_GUI.cookTimePanel.add(Box.createHorizontalStrut(10));
		View_GUI.cookTimePanel.add(min2);

		JLabel ingredientLabel = new JLabel("Ingredients:");
		ingredientLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));
		ingredientLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		ingredientLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		View_GUI.ingredientPanel.setLayout(new BoxLayout(View_GUI.ingredientPanel, BoxLayout.X_AXIS));
		View_GUI.ingredientsPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		View_GUI.ingredientsPanel.setLayout(new BoxLayout(View_GUI.ingredientsPanel, BoxLayout.Y_AXIS));
		View_GUI.ingredientPanel.add(ingredientLabel);
		View_GUI.ingredientPanel.add(Box.createHorizontalStrut(65));
		View_GUI.ingredientPanel.add(View_GUI.ingredientsPanel);
		View_GUI.ingredientPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		for (int i = 0; i < recipe.getIngredient().size(); i++) {

			JLabel label = new JLabel();
			label.setFont(new Font("SansSerif", Font.PLAIN, 20));
			label.setText(cookBook.getInsideIngredientSentence(recipe, i));

			View_GUI.ingredientsPanel.add(label);
			View_GUI.ingredientsPanel.add(Box.createVerticalStrut(10));

		}

		JLabel stepLabel = new JLabel("Steps:");
		stepLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));
		stepLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		stepLabel.setAlignmentY(Component.TOP_ALIGNMENT);

		View_GUI.stepPanel.setLayout(new BoxLayout(View_GUI.stepPanel, BoxLayout.X_AXIS));
		View_GUI.stepsPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		View_GUI.stepsPanel.setLayout(new BoxLayout(View_GUI.stepsPanel, BoxLayout.Y_AXIS));
		View_GUI.stepPanel.add(stepLabel);
		View_GUI.stepPanel.add(Box.createHorizontalStrut(110));
		View_GUI.stepPanel.add(View_GUI.stepsPanel);
		View_GUI.stepPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

		for (int i = 0; i < recipe.getSteps().size(); i++) {

			JLabel label = new JLabel();
			label.setFont(new Font("SansSerif", Font.PLAIN, 20));
			label.setText((i + 1) + "." + " " + cookBook.getStepSentence(recipe.getDishName(), i));

			View_GUI.stepsPanel.add(label);
			View_GUI.stepsPanel.add(Box.createVerticalStrut(10));

		}

		View_GUI.frame.revalidate();

	}

	/**
	 * Transmitting all the recipe information to Edit_GUI
	 */

	public void viewToEdit() {
		int countStepText1 = 100;
		int countIngredientText1 = 20;

		LinkedList<JTextField> ingredientTextField1 = new LinkedList<JTextField>();
		LinkedList<Box> ingredientBoxList1 = new LinkedList<Box>();
		LinkedList<Box> stepBoxList1 = new LinkedList<Box>();
		LinkedList<JTextField> stepList1 = new LinkedList<JTextField>();
		int countStep = 0;
		int countIngredient = 0;
		try {
			Edit_GUI.targetRecipe = cookBook.catchRecipe(Edit_GUI.recipeName);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		try {
			
			edit_GUI.panel_2.removeAll();
			edit_GUI.panel_2.setMaximumSize(new Dimension(4000,100));
			Box horizontalBox_8 = Box.createHorizontalBox();
			
			horizontalBox_8.setMaximumSize(new Dimension(4000, 30));
			edit_GUI.panel_2.add(horizontalBox_8);
			Component horizontalStrut_8 = Box.createHorizontalStrut((int)(width*0.078));
			horizontalBox_8.add(horizontalStrut_8);
			JLabel lblName = new JLabel("Name");
			lblName.setFont(new Font("SansSerif", Font.PLAIN, 26));
			horizontalBox_8.add(lblName);

			Component horizontalStrut_9 = Box.createHorizontalStrut((int)(width*0.13));
			horizontalBox_8.add(horizontalStrut_9);
			JLabel lblQuantity = new JLabel("Quantity");
			lblQuantity.setFont(new Font("SansSerif", Font.PLAIN, 26));
			horizontalBox_8.add(lblQuantity);

			Component horizontalStrut_10 = Box.createHorizontalStrut((int)(width*0.15625));
			horizontalBox_8.add(horizontalStrut_10);
			JLabel lblUnit = new JLabel("Unit");
			lblUnit.setFont(new Font("SansSerif", Font.PLAIN, 26));
			horizontalBox_8.add(lblUnit);

			Component horizontalStrut_20 = Box.createHorizontalStrut((int)(width*0.15625));
			horizontalBox_8.add(horizontalStrut_20);
			JLabel lblDescription = new JLabel("Description");
			lblDescription.setFont(new Font("SansSerif", Font.PLAIN, 26));
			horizontalBox_8.add(lblDescription);
			edit_GUI.panel_3.removeAll();
			edit_GUI.chckbxSalty.setSelected(false);
			edit_GUI.chckbxSour.setSelected(false);
			edit_GUI.chckbxSweet.setSelected(false);
			edit_GUI.chckbxSpicy.setSelected(false);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Edit_GUI.textField_1.setText((Edit_GUI.targetRecipe.getDishName()));
		Edit_GUI.textField_1.setEditable(false);
		Edit_GUI.textField_2.setText((Edit_GUI.targetRecipe.getLocation()));
		Edit_GUI.textField_3.setText(Integer.toString(Edit_GUI.targetRecipe.getPreparationTime()));
		Edit_GUI.textField_4.setText(Integer.toString(Edit_GUI.targetRecipe.getCookingTime()));
		Recipe recipe = Edit_GUI.targetRecipe;
		
		Edit_GUI.comboBox.setSelectedIndex(Edit_GUI.targetRecipe.getServings() - 1);
		for (int i = 0; i < Edit_GUI.targetRecipe.getTagList().size(); i++) {
			if (recipe.getTagList().get(i).getTagContent().equals("sweet")) {
				Edit_GUI.chckbxSweet.setSelected(true);
			}
			if (recipe.getTagList().get(i).getTagContent().equals("salty")) {
				Edit_GUI.chckbxSalty.setSelected(true);
			}
			if (recipe.getTagList().get(i).getTagContent().equals("spicy")) {
				Edit_GUI.chckbxSpicy.setSelected(true);
			}
			if (recipe.getTagList().get(i).getTagContent().equals("sour")) {
				Edit_GUI.chckbxSour.setSelected(true);
			}

		}

		countIngredient = recipe.getIngredient().size();
		countStep = recipe.getSteps().size();
		
		for (int i3 = 0; i3 < countStep; i3++) {
			
			Box box = Box.createHorizontalBox();
			stepBoxList1.add(box);
			JTextField tfield = new JTextField();

			box.add(tfield);
			tfield.setFont(new Font("SansSerif",Font.PLAIN,24));
			Edit_GUI.panel_3.add(box);
			countStepText1++;

			tfield.setColumns(10);
			tfield.setMaximumSize(new Dimension(4000, 30));
			stepList1.add(tfield);

		}
		edit_GUI.revalidate();

		if (countStepText1 == 100) {

		} else {
			
			int counter = countStepText1 - 100;
			for (int n = 0; n < counter; n++) {

				stepList1.get(n).setText(recipe.getSteps().get(n));

			}

			for (int i2 = 0; i2 < countIngredient; i2++) {
				
				Box box = Box.createHorizontalBox();
				ingredientBoxList1.add(box);
				Edit_GUI.panel_2.add(box);

				for (int i1 = 1; i1 <= 4; i1++) {
					
					JTextField tfield = new JTextField();
					tfield.setColumns(10);
					tfield.setMaximumSize(new Dimension(1000, 30));
					tfield.setFont(new Font("SansSerif",Font.PLAIN,24));
					box.add(tfield);
					ingredientTextField1.add(tfield);
					countIngredientText1++;

				}

			}
			edit_GUI.revalidate();
			if (countIngredientText1 == 20) {

			} else {
				int counter1 = (countIngredientText1 - 20) / 4;
				for (int n = 0; n < counter1; n++) {
					
					ingredientTextField1.get((n) * 4).setText(recipe.getIngredient().get((n)).getIngredientName());
					ingredientTextField1.get(1 + (n) * 4)
							.setText(Double.toString(recipe.getIngredient().get((n)).getQuantity()));
					ingredientTextField1.get(2 + (n) * 4).setText(recipe.getIngredient().get((n)).getUnit());
					ingredientTextField1.get(3 + (n) * 4).setText(recipe.getIngredient().get((n)).getDescription());
					if (recipe.getIngredient().get((n)).getDescription().equals("null")) {
						ingredientTextField1.get(3 + (n) * 4).setText("");
						
					}
				}
			}
			
			Edit_GUI.ingredientTextField = ingredientTextField1;
			Edit_GUI.ingredientBoxList = ingredientBoxList1;
			Edit_GUI.stepBoxList = stepBoxList1;
			Edit_GUI.stepList = stepList1;
			Edit_GUI.countIngredientText = countIngredientText1;
			Edit_GUI.countStepText = countStepText1;
			edit_GUI.frame.revalidate();
		}
	}

}