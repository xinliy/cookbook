package controller;

import view.Cover;
import view.Create_GUI;
import view.DeleteWindow;
import view.Edit_GUI;
import view.Search_GUI;
import view.View_GUI;

/**
 * The entrance of the whole software
 * 
 * @version 1.0
 */

public class Start {
	public static void main(String[] args) {
		
		Create_GUI create_GUI = new Create_GUI();
		DeleteWindow deleteWindow = new DeleteWindow();
		Edit_GUI edit_GUI = new Edit_GUI();
		Search_GUI search_GUI = new Search_GUI();
		View_GUI step_GUI = new View_GUI();
		Cover cover = new Cover();
		Controller controller = new Controller(create_GUI, deleteWindow, edit_GUI, search_GUI, step_GUI, cover);
		controller.cover.showGUI();
	}
}