package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import controller.Controller;
import business_logic.Ingredient;
import business_logic.Recipe;
import business_logic.Tag;
import business_logic.DBConnector;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.JButton;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

/**
 * The GUI of creating a new recipe
 * 
 * @author Song Yuchao
 * @version 1.0
 */
public class Create_GUI extends View_Superclass {

	private static final long serialVersionUID = 1L;
	public static JFrame frame;
	public static JPanel contentPane;
	public static JTextField textField_1;
	public static JTextField textField_2;
	public static JTextField textField_3;
	public static JTextField textField_4;
	public static JTextField textField_5;
	public static JTextField textField_6;
	public static JTextField textField_7;
	public static JTextField textField_8;
	public static JTextField textField_9;
	public static int countIngredientText;
	public static int countStepText;
	public static int countBox;
	public static Box box;
	public static JTextField tfield;
	public static LinkedList<JTextField> ingredientTextField = new LinkedList<JTextField>();
	public static LinkedList<Box> ingredientBoxList = new LinkedList<Box>();
	public static LinkedList<JTextField> stepList = new LinkedList<JTextField>();
	public static DBConnector dbconnector;
	public static JPanel panel_2;
	public static JButton btnAdd;
	public static JButton btnDeleteIngredient;
	public static JButton btnAddAStep;
	public static JPanel panel_3;
	public static JButton deleteStepButton;
	public static JButton btnSave;
	public static JComboBox comboBox;
	public static JCheckBox chckbxSpicy;
	public static JCheckBox chckbxSalty;
	public static JCheckBox chckbxSweet;
	public static JCheckBox chckbxSour;
	public static JButton btnBack;



	/**
	 * Create the frame.
	 */

	public Create_GUI() {

		// getting the center of user's pc, place the windows in the center
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();
		frame = new JFrame();
		countStepText = 100;
		countIngredientText = 20;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		Box horizontalBox = Box.createHorizontalBox();
		horizontalBox.setAlignmentX(Component.LEFT_ALIGNMENT);
		horizontalBox.setAlignmentY(Component.CENTER_ALIGNMENT);
		contentPane.add(horizontalBox);
		btnBack = new JButton("Back");
		btnBack.setFont(new Font("SansSerif", Font.BOLD, 24));
		horizontalBox.add(btnBack);
		Component horizontalGlue = Box.createHorizontalGlue();
		horizontalBox.add(horizontalGlue);
		btnSave = new JButton("Save");
		btnSave.setFont(new Font("SansSerif", Font.BOLD, 24));
		horizontalBox.add(btnSave);
		Box horizontalBox_1 = Box.createHorizontalBox();
		horizontalBox_1.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_1);

		Component horizontalStrut_12 = Box.createHorizontalStrut(100);
		horizontalBox_1.add(horizontalStrut_12);
		JLabel lblNewLabel = new JLabel("Recipe name:");
		lblNewLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));
		lblNewLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		horizontalBox_1.add(lblNewLabel);
		Component horizontalStrut_1 = Box.createHorizontalStrut(135);
		horizontalBox_1.add(horizontalStrut_1);
		textField_1 = new JTextField();
		textField_1.setBackground(Color.WHITE);
		textField_1.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setMaximumSize(new Dimension(400, 30));
		horizontalBox_1.add(textField_1);
		textField_1.setColumns(10);

		Component verticalStrut = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut);
		Box horizontalBox_13 = Box.createHorizontalBox();
		horizontalBox_13.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_13);

		Component horizontalStrut_13 = Box.createHorizontalStrut(100);
		horizontalBox_13.add(horizontalStrut_13);
		JLabel lblLocation = new JLabel("Location:");
		lblLocation.setFont(new Font("SansSerif", Font.PLAIN, 26));
		lblLocation.setAlignmentX(0.5f);
		horizontalBox_13.add(lblLocation);
		Component horizontalStrut_2 = Box.createHorizontalStrut(190);
		horizontalBox_13.add(horizontalStrut_2);
		textField_2 = new JTextField();
		textField_2.setBackground(Color.WHITE);
		textField_2.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setMaximumSize(new Dimension(400, 30));
		textField_2.setColumns(10);
		horizontalBox_13.add(textField_2);

		Component verticalStrut_1 = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut_1);
		Box horizontalBox_2 = Box.createHorizontalBox();
		horizontalBox_2.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_2);

		Component horizontalStrut_24 = Box.createHorizontalStrut(100);
		horizontalBox_2.add(horizontalStrut_24);
		JLabel lblNewLabel_1 = new JLabel("Flavor:");
		lblNewLabel_1.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_2.add(lblNewLabel_1);
		Component horizontalStrut_3 = Box.createHorizontalStrut(210);
		horizontalBox_2.add(horizontalStrut_3);
		chckbxSpicy = new JCheckBox("Sweet");
		chckbxSpicy.setBackground(Color.WHITE);
		chckbxSpicy.setForeground(Color.GREEN);
		chckbxSpicy.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 26));
		horizontalBox_2.add(chckbxSpicy);
		chckbxSalty = new JCheckBox("Salty");
		chckbxSalty.setBackground(Color.WHITE);
		chckbxSalty.setForeground(Color.DARK_GRAY);
		chckbxSalty.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 26));
		horizontalBox_2.add(chckbxSalty);
		chckbxSweet = new JCheckBox("Spicy");
		chckbxSweet.setBackground(Color.WHITE);
		chckbxSweet.setForeground(Color.RED);
		chckbxSweet.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 26));
		horizontalBox_2.add(chckbxSweet);
		chckbxSour = new JCheckBox("Sour");
		chckbxSour.setBackground(Color.WHITE);
		chckbxSour.setForeground(Color.ORANGE);
		chckbxSour.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 26));
		horizontalBox_2.add(chckbxSour);

		Component verticalStrut_2 = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut_2);
		Box horizontalBox_3 = Box.createHorizontalBox();
		horizontalBox_3.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_3);

		Component horizontalStrut_14 = Box.createHorizontalStrut(100);
		horizontalBox_3.add(horizontalStrut_14);
		JLabel lblNewLabel_2 = new JLabel("Servings:");
		lblNewLabel_2.setFont(new Font("SansSerif", Font.PLAIN, 26));
		lblNewLabel_2.setAlignmentX(Component.CENTER_ALIGNMENT);
		horizontalBox_3.add(lblNewLabel_2);
		Component horizontalStrut_7 = Box.createHorizontalStrut(185);
		horizontalBox_3.add(horizontalStrut_7);
		comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setMaximumRowCount(4);
		comboBox.setMaximumSize(new Dimension(100, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
		horizontalBox_3.add(comboBox);

		Component verticalStrut_3 = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut_3);
		Box horizontalBox_4 = Box.createHorizontalBox();
		horizontalBox_4.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_4);

		Component horizontalStrut_15 = Box.createHorizontalStrut(100);
		horizontalBox_4.add(horizontalStrut_15);
		JLabel lblNewLabel_3 = new JLabel("Prepare time:");
		lblNewLabel_3.setFont(new Font("SansSerif", Font.PLAIN, 26));
		lblNewLabel_3.setAlignmentX(Component.CENTER_ALIGNMENT);
		horizontalBox_4.add(lblNewLabel_3);
		Component horizontalStrut_4 = Box.createHorizontalStrut(140);
		horizontalBox_4.add(horizontalStrut_4);
		textField_3 = new JTextField();
		textField_3.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setMaximumSize(new Dimension(100, 30));
		horizontalBox_4.add(textField_3);
		textField_3.setColumns(10);

		Component pt = Box.createHorizontalStrut(10);
		horizontalBox_4.add(pt);

		JLabel min1 = new JLabel("Min");
		min1.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_4.add(min1);

		Component verticalStrut_4 = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut_4);

		Box horizontalBox_5 = Box.createHorizontalBox();
		horizontalBox_5.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_5);

		Component horizontalStrut_16 = Box.createHorizontalStrut(100);
		horizontalBox_5.add(horizontalStrut_16);
		JLabel lblNewLabel_4 = new JLabel("Cooking time:");
		lblNewLabel_4.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_5.add(lblNewLabel_4);
		Component horizontalStrut_11 = Box.createHorizontalStrut(135);
		horizontalBox_5.add(horizontalStrut_11);
		textField_4 = new JTextField();
		textField_4.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setMaximumSize(new Dimension(100, 30));
		horizontalBox_5.add(textField_4);

		Component ct = Box.createHorizontalStrut(10);
		horizontalBox_5.add(ct);

		JLabel min2 = new JLabel("Min");
		min2.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_5.add(min2);
		textField_4.setColumns(10);

		Component verticalStrut_5 = Box.createVerticalStrut(20);
		contentPane.add(verticalStrut_5);

		Component verticalGlue = Box.createVerticalGlue();
		contentPane.add(verticalGlue);

		Box horizontalBox_6 = Box.createHorizontalBox();
		horizontalBox_6.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_6);

		Component horizontalStrut_18 = Box.createHorizontalStrut(100);
		horizontalBox_6.add(horizontalStrut_18);
		JLabel lblIngredients = new JLabel("Ingredients:");
		lblIngredients.setAlignmentY(Component.TOP_ALIGNMENT);
		lblIngredients.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_6.add(lblIngredients);
		Component horizontalStrut = Box.createHorizontalStrut(160);
		horizontalBox_6.add(horizontalStrut);
		JPanel panel = new JPanel();
		panel.setAlignmentY(Component.TOP_ALIGNMENT);
		panel.setMaximumSize(new Dimension(4000, 250));
		panel.setMinimumSize(new Dimension(1, 250));
		horizontalBox_6.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane);
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setBorder(new EmptyBorder(0, 0, 0, 0));
		scrollPane.setViewportView(panel_2);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.Y_AXIS));
		Box horizontalBox_8 = Box.createHorizontalBox();
		horizontalBox_8.setAlignmentX(Component.LEFT_ALIGNMENT);
		horizontalBox_8.setMaximumSize(new Dimension(4000, 30));
		panel_2.add(horizontalBox_8);

		Component horizontalStrut_8 = Box.createHorizontalStrut(150);
		horizontalBox_8.add(horizontalStrut_8);
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_8.add(lblName);

		Component horizontalStrut_9 = Box.createHorizontalStrut(280);
		horizontalBox_8.add(horizontalStrut_9);
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_8.add(lblQuantity);

		Component horizontalStrut_10 = Box.createHorizontalStrut(280);
		horizontalBox_8.add(horizontalStrut_10);
		JLabel lblUnit = new JLabel("Unit");
		lblUnit.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_8.add(lblUnit);

		Component horizontalStrut_20 = Box.createHorizontalStrut(270);
		horizontalBox_8.add(horizontalStrut_20);
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_8.add(lblDescription);
		Box horizontalBox_9 = Box.createHorizontalBox();
		horizontalBox_9.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel_2.add(horizontalBox_9);
		textField_5 = new JTextField();
		textField_5.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_5.setMaximumSize(new Dimension(1000, 30));
		textField_5.setColumns(10);
		horizontalBox_9.add(textField_5);
		textField_6 = new JTextField();
		textField_6.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_6.setMaximumSize(new Dimension(1000, 30));
		textField_6.setColumns(10);
		horizontalBox_9.add(textField_6);
		textField_7 = new JTextField();
		textField_7.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_7.setMaximumSize(new Dimension(1000, 30));
		textField_7.setColumns(10);
		horizontalBox_9.add(textField_7);
		textField_8 = new JTextField();
		textField_8.setFont(new Font("SansSerif", Font.PLAIN, 24));
		textField_8.setMaximumSize(new Dimension(1000, 30));
		textField_8.setColumns(10);
		horizontalBox_9.add(textField_8);

		Component horizontalStrut_23 = Box.createHorizontalStrut(100);
		horizontalBox_6.add(horizontalStrut_23);
		Box horizontalBox_11 = Box.createHorizontalBox();
		horizontalBox_11.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_11);

		btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("SansSerif", Font.PLAIN, 30));

		Component horizontalStrut_17 = Box.createHorizontalStrut(100);
		horizontalBox_11.add(horizontalStrut_17);

		Component horizontalGlue_1 = Box.createHorizontalGlue();
		horizontalBox_11.add(horizontalGlue_1);

		horizontalBox_11.add(btnAdd);

		Component horizontalStrut_6 = Box.createHorizontalStrut(20);
		horizontalBox_11.add(horizontalStrut_6);

		btnDeleteIngredient = new JButton("Delete");
		btnDeleteIngredient.setFont(new Font("SansSerif", Font.PLAIN, 30));

		horizontalBox_11.add(btnDeleteIngredient);

		Component horizontalGlue_2 = Box.createHorizontalGlue();
		horizontalBox_11.add(horizontalGlue_2);

		Box horizontalBox_7 = Box.createHorizontalBox();
		horizontalBox_7.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_7);

		Component horizontalStrut_5 = Box.createHorizontalStrut(100);
		horizontalBox_7.add(horizontalStrut_5);
		JLabel lblSteps = new JLabel("Steps:");
		lblSteps.setAlignmentY(Component.TOP_ALIGNMENT);
		lblSteps.setFont(new Font("SansSerif", Font.PLAIN, 26));
		horizontalBox_7.add(lblSteps);

		Component horizontalStrut_21 = Box.createHorizontalStrut(220);
		horizontalBox_7.add(horizontalStrut_21);
		JPanel panel_1 = new JPanel();
		panel_1.setAlignmentY(Component.TOP_ALIGNMENT);
		horizontalBox_7.add(panel_1);
		panel_1.setMaximumSize(new Dimension(4000, 250));
		panel_1.setMinimumSize(new Dimension(1, 250));
		panel_1.setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane_1 = new JScrollPane();
		panel_1.add(scrollPane_1, BorderLayout.CENTER);
		panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		scrollPane_1.setViewportView(panel_3);
		panel_3.setLayout(new BoxLayout(panel_3, BoxLayout.Y_AXIS));
		Box horizontalBox_10 = Box.createHorizontalBox();
		panel_3.add(horizontalBox_10);
		textField_9 = new JTextField();
		textField_9.setFont(new Font("SansSerif", Font.PLAIN, 24));
		horizontalBox_10.add(textField_9);
		textField_9.setMaximumSize(new Dimension(4000, 30));
		textField_9.setColumns(10);

		Component horizontalStrut_25 = Box.createHorizontalStrut(100);
		horizontalBox_7.add(horizontalStrut_25);
		Box horizontalBox_12 = Box.createHorizontalBox();
		horizontalBox_12.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.add(horizontalBox_12);
		btnAddAStep = new JButton("Add");
		btnAddAStep.setFont(new Font("SansSerif", Font.PLAIN, 30));

		Component horizontalStrut_22 = Box.createHorizontalStrut(100);
		horizontalBox_12.add(horizontalStrut_22);

		Component horizontalGlue_3 = Box.createHorizontalGlue();
		horizontalBox_12.add(horizontalGlue_3);
		horizontalBox_12.add(btnAddAStep);

		Component horizontalStrut_19 = Box.createHorizontalStrut(20);
		horizontalBox_12.add(horizontalStrut_19);
		deleteStepButton = new JButton("Delete");
		deleteStepButton.setFont(new Font("SansSerif", Font.PLAIN, 30));
		horizontalBox_12.add(deleteStepButton);

		Component horizontalGlue_4 = Box.createHorizontalGlue();
		horizontalBox_12.add(horizontalGlue_4);

		frame.add(contentPane);

	}

	public void showGUI() {

		// getting the center of user's pc, place the windows in the center
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();
		frame.setSize(width*4/5, height*4/5);
		frame.setLocation(0, 0);
		frame.setVisible(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
			int confirmed = JOptionPane.showConfirmDialog(null,
			"Are you sure you want to exit?", "User Confirmation",
			JOptionPane.YES_NO_OPTION);
			if (confirmed == JOptionPane.YES_OPTION)
			frame.dispose();
			}
			});

		

	}

}