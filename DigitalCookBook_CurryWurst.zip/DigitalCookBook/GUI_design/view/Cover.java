package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * The cover of our digital cookbook software
 * 
 * @author Bing Guanqi, Song Yuchao
 * @version 1.0
 */
public class Cover extends View_Superclass {

	private JLabel pictureLabel = new JLabel();
	private ImageIcon background = null;
	private JButton enter = new JButton("Just Cook It!");


	public JButton getEnter() {
		return enter;
	}


	public void setEnter(JButton enter) {
		this.enter = enter;
	}

	public Cover() {

	}

	public void showGUI() {

		this.setTitle("Welcome to our recipe world!");

		// Getting the center of user's pc, place the windows in the center
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();
		this.setSize((int) (width * 0.75), (int) (height * 0.75));
		this.setLocation((width - (int) (width * 0.75)) / 2, (height - (int) (height * 0.75)) / 2);

		background = new ImageIcon(this.getClass().getResource("/icon/rou.jpg"));
		Image img = background.getImage();
		img = img.getScaledInstance((int) (width * 0.75), (int) (height * 0.75), Image.SCALE_DEFAULT);
		background.setImage(img);
		pictureLabel.setIcon(background);
		pictureLabel.setBounds(0, 0, (int) (width * 0.75), (int) (height * 0.75));
		this.getLayeredPane().add(pictureLabel, new Integer(Integer.MIN_VALUE));
		this.add(pictureLabel);

		enter.setBounds((int) (width * 0.22), (int) (height * 0.65), (int) (width * 0.278), (int) (height * 0.052));
		enter.setBackground(Color.RED);
		enter.setForeground(Color.WHITE);
		enter.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.022)));
		enter.setBorder(BorderFactory.createLineBorder(Color.red, 2, true));
		enter.setFocusPainted(false);
		this.add(enter);

		this.setLayout(null);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		

	}

}