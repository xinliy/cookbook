package view;

/**
 * The confirming window when you want to delete one recipe
 * 
 * @author Shan Xue, Bing Guanqi
 * @version 1.0
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DeleteWindow extends View_Superclass {
	public static JButton confirmButton = new JButton("Confirm");
	public static JButton cancelButton = new JButton("Cancel");
	public static JPanel buttonPanel = new JPanel();
	public static JPanel panel = new JPanel();
	public static JPanel labelPanel = new JPanel();
	public static JLabel confirmLabel = new JLabel("Are you sure to delete this recipe?");
	public static String dishName;
	public static JFrame frame;

	public DeleteWindow() {

	}

	public void showGUI() {

		frame = new JFrame();

		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();

		frame.setSize(280, 120);
		frame.setLocation((width - 280) / 2, (height - 120) / 2);

		labelPanel.add(confirmLabel);
		confirmLabel.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		labelPanel.setAlignmentY(Component.BOTTOM_ALIGNMENT);

		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(confirmButton);
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.add(cancelButton);
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(Box.createVerticalStrut(25));
		panel.add(labelPanel);
		panel.add(buttonPanel);
		panel.add(Box.createVerticalStrut(20));

		panel.setOpaque(true);

		confirmLabel.setFont(new Font("Arial", Font.BOLD, 14));

		confirmLabel.setForeground(Color.WHITE);
		confirmButton.setBackground(new Color(88, 87, 86));
		cancelButton.setBackground(new Color(88, 87, 86));
		confirmButton.setForeground(Color.white);
		cancelButton.setForeground(Color.WHITE);

		confirmButton.setFocusPainted(false);
		cancelButton.setFocusPainted(false);

		buttonPanel.setBackground(new Color(88, 87, 86));
		panel.setBackground(new Color(88, 87, 86));
		labelPanel.setBackground(new Color(88, 87, 86));

		frame.setUndecorated(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(panel);
		frame.getContentPane().setBackground(new Color(88, 87, 86));
		frame.setVisible(true);
	}

}
