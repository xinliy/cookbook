package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 * The GUI of search of our software
 * 
 * @author Bing Guanqi
 * @version 1.0
 *
 */
public class Search_GUI extends View_Superclass {
	public static JPanel middlePanel = new JPanel();
	public static JPanel topPanel = new JPanel();
	public static JPanel panelContainer = new JPanel();
	public static JPanel bottomPanel = new JPanel();
	public static JPanel[] innerPanel = new JPanel[20];
	public static JPanel emptyPanel = new JPanel();
	public static JPanel panel = new JPanel();
	public static JScrollPane scrollPane = new JScrollPane();

	public static JButton jb_add = new JButton("Add your own recipe");
	public static JTextField jtf_search = new JTextField("Dish Name/Ingredient", 80);
	public final static String[] flavor = { "sweet", "spicy", "salty", "sour", "All flavor" };
	public static JComboBox<Object> jcb_flavor = new JComboBox<Object>(flavor);
	public static JButton jb_search = new JButton("SEARCH");
	public static JLabel jl_search = new JLabel();
	public static ImageIcon search_logo = null;

	public static JLabel jl_result = new JLabel("We have found the following recipe(s):");
	public static JLabel[] jl_name = new JLabel[20];
	public static JLabel[] jl_prepTime = new JLabel[20];
	public static JLabel[] jl_cookTime = new JLabel[20];
	public static JLabel[] jl_ingredients = new JLabel[20];
	public static JLabel[] jl_targetPrepTime = new JLabel[20];
	public static JLabel[] jl_targetCookTime = new JLabel[20];
	public static JLabel[] jl_targetIngredients = new JLabel[20];
	public static JLabel[] jl_flavor1 = new JLabel[20];
	public static JLabel[] jl_flavor2 = new JLabel[20];
	public static JLabel[] jl_flavor3 = new JLabel[20];
	public static JLabel[] jl_flavor4 = new JLabel[20];

	public static Box box1 = Box.createHorizontalBox(); // placing jl_result
	public static Box[] box_name = new Box[20];
	public static Box[] box_prepTime = new Box[20];
	public static Box[] box_cookTime = new Box[20];
	public static Box[] box_ingredients = new Box[20];
	public static Box[] box_flavor = new Box[20];
	public static Box[] box_recipe = new Box[20];
	public static Box[] box_box = new Box[20];
	public static Box[] box_bottomHoriBox = new Box[20];
	public static Box box_bottomPanelItem = Box.createVerticalBox();

	public Search_GUI() {

		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();
		this.setSize((int) (width * 0.56), (int) (height * 0.625));
		this.setLocation((width - (int) (width * 0.56)) / 2, (height - (int) (height * 0.625)) / 2);

		for (int i = 0; i < 20; i++) {
			jl_name[i] = new JLabel();
		}
		for (int i = 0; i < 20; i++) {
			jl_prepTime[i] = new JLabel("Preparing Time:");
		}
		for (int i = 0; i < 20; i++) {
			jl_cookTime[i] = new JLabel("Cooking Time:");
		}
		for (int i = 0; i < 20; i++) {
			jl_ingredients[i] = new JLabel("Ingredients: ");
		}
		for (int i = 0; i < 20; i++) {
			jl_targetPrepTime[i] = new JLabel();
		}
		for (int i = 0; i < 20; i++) {
			jl_targetCookTime[i] = new JLabel();
		}
		for (int i = 0; i < 20; i++) {
			jl_targetIngredients[i] = new JLabel();
		}
		for (int i = 0; i < 20; i++) {
			jl_flavor1[i] = new JLabel("Sweet");
			jl_flavor1[i].setPreferredSize(new Dimension((int) (width * 0.03), (int) (height * 0.026)));
		}
		for (int i = 0; i < 20; i++) {
			jl_flavor2[i] = new JLabel("Salty");
			jl_flavor2[i].setPreferredSize(new Dimension((int) (width * 0.03), (int) (height * 0.026)));
		}
		for (int i = 0; i < 20; i++) {
			jl_flavor3[i] = new JLabel("Spicy");
			jl_flavor3[i].setPreferredSize(new Dimension((int) (width * 0.03), (int) (height * 0.026)));
		}
		for (int i = 0; i < 20; i++) {
			jl_flavor4[i] = new JLabel("Sour");
			jl_flavor4[i].setPreferredSize(new Dimension((int) (width * 0.03), (int) (height * 0.026)));
		}

		for (int i = 0; i < 20; i++) {
			box_name[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_prepTime[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_cookTime[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_ingredients[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_flavor[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_recipe[i] = Box.createVerticalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_box[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			box_bottomHoriBox[i] = Box.createHorizontalBox();
		}
		for (int i = 0; i < 20; i++) {
			innerPanel[i] = new JPanel();
			innerPanel[i].setPreferredSize(new Dimension((int) (width * 0.2), (int) (height * 0.17)));
			innerPanel[i].setMaximumSize(new Dimension((int) (width * 0.2), (int) (height * 0.17)));
			innerPanel[i].setBackground(Color.WHITE);
		}

		// setting the button of add
		jb_add.setSize((int) (width * 0.15), (int) (height * 0.026));
		jb_add.setBackground(new Color(212, 73, 70));
		jb_add.setForeground(Color.WHITE);
		jb_add.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.01464)));
		jb_add.setHorizontalAlignment(JButton.CENTER);
		jb_add.setBorder(BorderFactory.createLineBorder(new Color(212, 73, 70), 1, true));

		// setting the search logo
		search_logo = new ImageIcon(this.getClass().getResource("/icon/icon.png"));
		Image img = search_logo.getImage();
		img = img.getScaledInstance((int) (width * 0.014), (int) (height * 0.024), Image.SCALE_DEFAULT);
		search_logo.setImage(img);
		jl_search.setIcon(search_logo);
		jl_search.setSize((int) (width * 0.022), (int) (height * 0.04));

		// setting the search textfield
		jtf_search.setSize((int) (width * 0.01464), search_logo.getIconHeight());
		jtf_search.setMaximumSize(new Dimension((int) (width), (int) (height * 0.027778)));
		jtf_search.setBorder(BorderFactory.createLineBorder(Color.gray, 1, true));
		jtf_search.setHorizontalAlignment(JTextField.LEFT);
		jtf_search.setForeground(Color.gray);
		jtf_search.setFont(new Font("Arial", Font.PLAIN, (int) (width * 0.01)));

		// setting the combo box of flavor
		jcb_flavor.setBackground(Color.WHITE);
		jcb_flavor.setSize((int) (width * 0.0732), (int) (height * 0.039));
		jcb_flavor.setMaximumSize(new Dimension((int) (width * 0.0732), (int) (height * 0.028778)));
		jcb_flavor.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.01)));
		jcb_flavor.setBorder(BorderFactory.createLineBorder(Color.white, 1, true));
		jcb_flavor.setSelectedIndex(4);

		// setting the button of search
		jb_search.setSize((int) (width * 0.732), (int) (height * 0.04));
		jb_search.setBackground(new Color(212, 73, 70));
		jb_search.setForeground(Color.WHITE);
		jb_search.setFont(new Font("Arial", Font.BOLD, (int) (width * 0.011)));
		jb_search.setHorizontalAlignment(JButton.CENTER);
		jb_search.setBorder(BorderFactory.createLineBorder(new Color(212, 73, 70), 1, true));

		middlePanel.setBackground(Color.WHITE);
		middlePanel.add(Box.createGlue());
		middlePanel.add(jb_add);
		middlePanel.add(Box.createHorizontalStrut((int) (width * 0.0146)));

		topPanel.setBackground(Color.WHITE);
		topPanel.setLayout(new FlowLayout());
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
		topPanel.add(Box.createHorizontalStrut((int) (width * 0.0146)));
		topPanel.add(jl_search);
		topPanel.add(jtf_search);
		topPanel.add(Box.createHorizontalStrut((int) (width * 0.0073)));
		topPanel.add(jcb_flavor);
		topPanel.add(Box.createHorizontalStrut((int) (width * 0.0073)));
		topPanel.add(jb_search);
		topPanel.add(Box.createHorizontalStrut((int) (width * 0.0146)));

		bottomPanel.setBackground(Color.WHITE);
		bottomPanel.setBorder(BorderFactory.createLineBorder(Color.red));

		panelContainer.setBackground(Color.WHITE);
		panelContainer.setLayout(new GridBagLayout());
		panelContainer.setPreferredSize(new Dimension((int) (width * 0.5344), (int) (width * 0.86)));

		GridBagConstraints c0 = new GridBagConstraints();
		c0.gridwidth = 0;
		c0.gridheight = 1;
		c0.weightx = 1;
		c0.weighty = 0;
		c0.fill = GridBagConstraints.BOTH;
		panelContainer.add(emptyPanel, c0);
		emptyPanel.setBackground(Color.WHITE);
		emptyPanel.setMinimumSize(new Dimension((int) (width * 0.0366), (int) (height * 0.04)));

		GridBagConstraints c1 = new GridBagConstraints();
		c1.gridwidth = 0;
		c1.gridheight = 1;
		c1.weightx = 1;
		c1.weighty = 0;
		c1.fill = GridBagConstraints.BOTH;
		panelContainer.add(topPanel, c1);

		GridBagConstraints c2 = new GridBagConstraints();
		c2.gridwidth = 0;
		c2.gridheight = 1;
		c2.weightx = 1;
		c2.weighty = 0;
		c2.fill = GridBagConstraints.BOTH;
		panelContainer.add(middlePanel, c2);

		GridBagConstraints c3 = new GridBagConstraints();
		c1.gridwidth = 0;
		c1.gridheight = 1;
		c1.weightx = 1;
		c1.weighty = 0;
		c1.fill = GridBagConstraints.BOTH;
		panelContainer.add(new JPanel(), c3);

		GridBagConstraints c4 = new GridBagConstraints();
		c4.gridwidth = 0;
		c4.gridheight = 0;
		c4.weightx = 1;
		c4.weighty = 1;
		c4.fill = GridBagConstraints.BOTH;
		panelContainer.add(bottomPanel, c4);

		scrollPane.setViewportView(panelContainer);
		scrollPane.setPreferredSize(new Dimension((int) (width * 0.56), (int) (height * 0.225)));
		scrollPane.setMaximumSize(new Dimension((int) (width * 0.56), (int) (height * 0.225)));

		panelContainer.setOpaque(true);
		panelContainer.setBackground(Color.WHITE);
		scrollPane.setOpaque(true);
		scrollPane.setBackground(Color.WHITE);
		this.setContentPane(scrollPane);

	}

	public void showGUI() {

		this.setVisible(true);
		this.setResizable(true);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
			int confirmed = JOptionPane.showConfirmDialog(null,
			"Are you sure you want to exit?", "User Confirmation",
			JOptionPane.YES_NO_OPTION);
			if (confirmed == JOptionPane.YES_OPTION)
			dispose();
			}
			});
	}
	

}
