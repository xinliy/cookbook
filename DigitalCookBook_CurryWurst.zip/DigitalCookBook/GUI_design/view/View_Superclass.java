package view;

import java.awt.Frame;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

/**
 * View_Superclass to define all the listener methods
 * 
 * @author Zhang Xiaoyue
 * @version 1.0
 *
 */
public class View_Superclass extends JFrame {

	public void addListener(ActionListener listen, JButton button) {
		button.addActionListener(listen);
	}

	public void addMouseListener(MouseListener mouseListener, JTextField jTextField) {
		jTextField.addMouseListener(mouseListener);
	}

	public void addKeyListener(KeyListener keyListener, JTextField jTextField) {
		jTextField.addKeyListener(keyListener);
	}

}
