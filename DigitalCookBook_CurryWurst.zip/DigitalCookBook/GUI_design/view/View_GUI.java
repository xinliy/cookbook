package view;

import java.awt.Color;

import java.awt.Component;

import java.awt.Dimension;

import java.awt.Font;

import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.awt.event.WindowListener;

import java.sql.SQLException;

import javax.swing.BorderFactory;

import javax.swing.Box;

import javax.swing.BoxLayout;

import javax.swing.JButton;

import javax.swing.JComboBox;

import javax.swing.JFrame;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import javax.swing.JScrollPane;

import business_logic.CookBook;

import business_logic.Recipe;

import controller.Controller;

/**
 * The GUI of search of our software
 * 
 * @author Shan Xue
 * @version 1.0
 */
public class View_GUI extends View_Superclass {

	static public Recipe recipe;

	static public JPanel topPanel;

	static public JPanel locationPanel;

	static public JPanel flavorPanel;

	static public JPanel servingPanel;

	static public JPanel prepareTimePanel;

	static public JPanel cookTimePanel;

	static public JPanel ingredientPanel;

	static public JPanel ingredientsPanel;

	static public JPanel stepPanel;

	static public JPanel stepsPanel;

	static public JPanel bottomPanel;

	static public JComboBox servingComboBox;

	static public JLabel dishName;

	static public JLabel prepareTimeLabel;

	static public String recipeName;

	static public JButton changeServings;

	static public JButton backButton = new JButton("BACK");

	static public JButton editButton = new JButton("EDIT");

	static public JButton deleteButton = new JButton("DELETE");

	static public JFrame frame;

	static public int counter = 0;

	static void createTopPanel() {

		dishName = new JLabel();

		backButton.setFont(new Font("SansSerif", Font.BOLD, 24));

		editButton.setFont(new Font("SansSerif", Font.BOLD, 24));

		topPanel = new JPanel();

		topPanel.setBackground(Color.WHITE);

		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));

		topPanel.add(backButton);

		topPanel.add(Box.createHorizontalGlue());

		topPanel.add(dishName);

		topPanel.add(Box.createHorizontalGlue());

		topPanel.add(editButton);

		// topPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createLocationPanel() {

		JLabel locationLabel = new JLabel("Location:");

		locationLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		locationLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		locationPanel = new JPanel();

		locationPanel.setBackground(Color.WHITE);

		locationPanel.setLayout(new BoxLayout(locationPanel, BoxLayout.X_AXIS));

		locationPanel.add(locationLabel);

		locationPanel.add(Box.createHorizontalStrut(65));

		locationPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createFlavorPanel() {

		JLabel flavorLabel = new JLabel("Flavors:");

		flavorLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		// flavorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		flavorPanel = new JPanel();

		flavorPanel.setBackground(Color.WHITE);

		flavorPanel.setLayout(new BoxLayout(flavorPanel, BoxLayout.X_AXIS));

		flavorPanel.add(flavorLabel);

		flavorPanel.add(Box.createHorizontalStrut(75));

		flavorPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createServingPanel() {

		String[] str = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };

		servingComboBox = new JComboBox(str);

		servingComboBox.setMaximumRowCount(4);

		servingComboBox.setMaximumSize(new Dimension(80, 26));

		JLabel servingLabel = new JLabel("Servings:");

		servingLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));

		changeServings = new JButton("Refresh");

		servingLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		servingPanel = new JPanel();

		servingPanel.setBackground(Color.WHITE);

		servingPanel.setLayout(new BoxLayout(servingPanel, BoxLayout.X_AXIS));

		servingPanel.add(servingLabel);

		servingPanel.add(Box.createHorizontalStrut(90));

		servingPanel.add(servingComboBox);

		servingPanel.add(Box.createHorizontalStrut(70));

		servingPanel.add(changeServings);

		servingPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createPrepareTimePanel() {

		JLabel prepareTimeLabel = new JLabel("Preparing time:");

		prepareTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		prepareTimeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		prepareTimePanel = new JPanel();

		prepareTimePanel.setBackground(Color.WHITE);

		prepareTimePanel.setLayout(new BoxLayout(prepareTimePanel, BoxLayout.X_AXIS));

		prepareTimePanel.add(prepareTimeLabel);

		prepareTimePanel.add(Box.createHorizontalStrut(36));

		prepareTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createCookTimePanel() {

		JLabel cookTimeLabel = new JLabel("Cooking time:");

		cookTimeLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		cookTimeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		cookTimePanel = new JPanel();

		cookTimePanel.setBackground(Color.WHITE);

		cookTimePanel.setLayout(new BoxLayout(cookTimePanel, BoxLayout.X_AXIS));

		cookTimePanel.add(cookTimeLabel);

		cookTimePanel.add(Box.createHorizontalStrut(50));

		cookTimePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createIngredientPanel() {

		JLabel ingredientLabel = new JLabel("Ingredients:");

		ingredientLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		ingredientLabel.setAlignmentY(Component.TOP_ALIGNMENT);

		ingredientLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		ingredientPanel = new JPanel();

		ingredientPanel.setBackground(Color.WHITE);

		ingredientPanel.setLayout(new BoxLayout(ingredientPanel, BoxLayout.X_AXIS));

		ingredientsPanel = new JPanel();

		ingredientsPanel.setBackground(Color.WHITE);

		ingredientsPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		ingredientsPanel.setLayout(new BoxLayout(ingredientsPanel, BoxLayout.Y_AXIS));

		ingredientPanel.add(ingredientLabel);

		ingredientPanel.add(Box.createHorizontalStrut(55));

		ingredientPanel.add(ingredientsPanel);

		ingredientPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createStepPanel() {

		JLabel stepLabel = new JLabel("Steps:");

		stepLabel.setFont(new Font("SansSerif", Font.PLAIN, 26));

		stepLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

		stepLabel.setAlignmentY(Component.TOP_ALIGNMENT);

		stepPanel = new JPanel();

		stepPanel.setBackground(Color.WHITE);

		stepPanel.setLayout(new BoxLayout(stepPanel, BoxLayout.X_AXIS));

		stepsPanel = new JPanel();

		stepsPanel.setBackground(Color.WHITE);

		stepsPanel.setLayout(new BoxLayout(stepsPanel, BoxLayout.Y_AXIS));

		stepsPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		stepPanel.add(stepLabel);

		stepPanel.add(Box.createHorizontalStrut(93));

		stepPanel.add(stepsPanel);

		stepPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

	}

	static void createBottomPanel() {

		bottomPanel = new JPanel();

		bottomPanel.setBackground(Color.WHITE);

		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));

		bottomPanel.add(Box.createHorizontalGlue());

		bottomPanel.add(deleteButton);

		bottomPanel.add(Box.createHorizontalGlue());

		deleteButton.setFont(new Font("SansSerif", Font.BOLD, 24));

	}

	public View_GUI() {

		frame = new JFrame();
		createTopPanel();

		createLocationPanel();

		createFlavorPanel();

		createServingPanel();

		createPrepareTimePanel();

		createCookTimePanel();

		createIngredientPanel();

		createStepPanel();

		createBottomPanel();

	}

	public void showGUI() {

		// getting the center of user's pc, place the windows in the center
		Toolkit tool = Toolkit.getDefaultToolkit();
		Dimension dim = tool.getScreenSize();
		int width = (int) dim.getWidth();
		int height = (int) dim.getHeight();
		frame.setSize(width*4/5, height*4/5);
		frame.setLocation(0, 0);

		JPanel panel = new JPanel();

		JScrollPane scrollPane = new JScrollPane(panel);

		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

		panel.add(topPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(locationPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(flavorPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(servingPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(prepareTimePanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(cookTimePanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(ingredientPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(stepPanel);

		panel.add(Box.createVerticalStrut(20));

		panel.add(bottomPanel);

		((JFrame) frame).setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
			int confirmed = JOptionPane.showConfirmDialog(null,
			"Are you sure you want to exit?", "User Confirmation",
			JOptionPane.YES_NO_OPTION);
			if (confirmed == JOptionPane.YES_OPTION)
			frame.dispose();
			}
			});

		panel.setOpaque(true);

		panel.setBackground(Color.WHITE);

		scrollPane.setOpaque(true);

		frame.setContentPane(scrollPane);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

	}
}