package JUnit_Test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import business_logic.CookBook;
import business_logic.DBConnector;
import business_logic.Ingredient;
import business_logic.Recipe;
import business_logic.Tag;

/**
 * JUnit Testing of class cookBook
 * 
 * @author Song Yuchao
 * @version 1.0
 */
public class CookBookTest {
	static private String cookBookName;
	static private CookBook cookbook;
	static private Recipe recipe;

	@BeforeClass
	public static void setUp() throws SQLException, ClassNotFoundException {
		cookBookName = "cookbook";
		cookbook = new CookBook(cookBookName);
		recipe = new Recipe(11, "Tomato and egg", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("cornstarch", 1.0, "tablespoon","mixed with water"));
		recipe.addIngredient(new Ingredient("Tomato", 1.0, "tablespoon"));
		recipe.addPreparationStep("Mix together cornstarch and 1 tbsp. of the soy sauce in a medium bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("sweet"));
		DBConnector dbConnector = new DBConnector();
		recipe.recipeToDatabase(dbConnector);
		cookbook.add(recipe);
	}

	@Test
	public void testCookBookString() {

		assertEquals(cookBookName, cookbook.getCookBookName());

	}

	@Test
	public void testAdd() {

		assertTrue(cookbook.getRecipeList().contains(recipe));

	}

	@Test
	public void testGetRecipe() {

		assertEquals(recipe, cookbook.getRecipe("Tomato and egg"));

	}

	@Test
	public void testGetIngredientNumbaer() throws SQLException, ClassNotFoundException {

		assertEquals(2, cookbook.getIngredientNumber("Tomato and egg"));
	}

	@Test
	public void testGetStepNumber() throws ClassNotFoundException, SQLException {

		assertEquals(1, cookbook.getStepNumber("Tomato and egg"));

	}

	@Test
	public void testGetStepSentence() throws ClassNotFoundException, SQLException {

		assertEquals("Mix together cornstarch and 1 tbsp. of the soy sauce in a medium bowl.",
				cookbook.getStepSentence("Tomato and egg", 0));

	}

	@Test
	public void testGetInsideIngredientSentence() throws ClassNotFoundException, SQLException {

		assertEquals("cornstarch 1.0 tablespoon mixed with water", cookbook.getInsideIngredientSentence(recipe, 0));

	}

	@Test
	public void testGetAllIngredientsName() throws ClassNotFoundException, SQLException {

		assertEquals("cornstarch, Tomato...", cookbook.getAllIngredientsName("Tomato and egg"));
	}

	@Test
	public void testGetAllTags() throws ClassNotFoundException, SQLException {

		assertEquals("sweet", cookbook.getAllTags("Tomato and egg").getFirst());
		assertEquals(1, cookbook.getAllTags("Tomato and egg").size());

	}

	@Test
	public void testSearchByNameAndIngredient() throws ClassNotFoundException, SQLException {

		assertEquals("Tomato and egg",
				cookbook.searchByNameAndIngredient("Tomato and egg", "All flavor").getFirst().getDishName());
	}


	@Test
	public void testSelectIdByName() throws ClassNotFoundException, SQLException {

		assertEquals(11, cookbook.selectIdByName("Tomato and egg"));
	}

	@Test
	public void testReturnRecipe() throws SQLException, ClassNotFoundException {

		Recipe recipe;
		recipe = new Recipe(12, "Steamed egg", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("egg", 4.0, "unit"));
		recipe.addPreparationStep("Stir the eggs in a bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		assertNotNull(cookbook.catchRecipe("Steamed egg"));

	}

	@Test
	public void testUpdateRecipe() throws ClassNotFoundException, SQLException {

		Recipe recipe;
		recipe = new Recipe(13, "Xiao Long Bao", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("egg", 4.0, "unit"));
		recipe.addPreparationStep("Stir the eggs in a bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		recipe.setDishName("New Dish");
		cookbook.updateRecipe(recipe);
		assertEquals(13, cookbook.selectIdByName("New Dish"));
	}

	@Test
	public void testRemoveAllIngredients() throws SQLException, ClassNotFoundException {

		Recipe recipe;
		recipe = new Recipe(14, "Shui Jiao", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("dumpling", 4.0, "unit"));
		recipe.addPreparationStep("Cook the rice.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		cookbook.removeAllIngredients(recipe);
		assertEquals(0, cookbook.getIngredientNumber("Shui Jiao"));
	}

	@Test
	public void testRemoveAllSteps() throws ClassNotFoundException, SQLException {

		Recipe recipe;
		recipe = new Recipe(15, "Man Tou", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("meat", 4.0, "unit"));
		recipe.addPreparationStep("Cook the rice.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		cookbook.removeAllSteps(recipe);
		assertEquals(0, cookbook.getStepNumber("Man Tou"));
	}

	@Test
	public void testRemoveAllTag() throws ClassNotFoundException, SQLException {

		Recipe recipe;
		recipe = new Recipe(16, "Qing Tuan", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("egg", 4.0, "unit"));
		recipe.addPreparationStep("Stir the eggs in a bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		cookbook.removeAllTag(recipe);

		assertEquals(0, cookbook.getAllTags("Qing Tuan").size());
	}

	
	@Test
	public void testDeleteRecipe() throws ClassNotFoundException, SQLException {

		Recipe recipe;
		recipe = new Recipe(17, "Chou Dou Fu", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("egg", 4.0, "unit"));
		recipe.addPreparationStep("Stir the eggs in a bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("salty"));
		cookbook.returnRecipe(recipe);
		cookbook.deleteRecipe(cookbook.catchRecipe("Chou Dou Fu").getRecipeId());
		assertNull(cookbook.catchRecipe("CHou Dou Fu"));

	}
	@Test
	public void testGetRecipeId() throws ClassNotFoundException, SQLException {

		assertEquals(17, cookbook.getRecipeId());

	}
	
	

	@AfterClass
	public static void tearDown() throws SQLException, ClassNotFoundException {
		cookbook.deleteRecipe(cookbook.catchRecipe("Tomato and egg").getRecipeId());
		cookbook.deleteRecipe(cookbook.catchRecipe("Steamed egg").getRecipeId());
		cookbook.deleteRecipe(cookbook.catchRecipe("New Dish").getRecipeId());
		cookbook.deleteRecipe(cookbook.catchRecipe("Shui Jiao").getRecipeId());
		cookbook.deleteRecipe(cookbook.catchRecipe("Man Tou").getRecipeId());
		cookbook.deleteRecipe(cookbook.catchRecipe("Qing Tuan").getRecipeId());

	}

}
