package JUnit_Test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import business_logic.Ingredient;

public class IngredientTest {

	@Test
	public void testIngredientStringDoubleString() throws ClassNotFoundException, SQLException {

		String ingredientName = "Pork";
		double quantity = 1.0;
		String unit = "kg";
		Ingredient ingredient = new Ingredient(ingredientName, quantity, unit);
		assertEquals(ingredientName, ingredient.getIngredientName());
		assertEquals(quantity, ingredient.getQuantity(), 0);
		assertEquals(unit, ingredient.getUnit());

	}

	@Test
	public void testIngredientStringDoubleStringString() throws ClassNotFoundException, SQLException {

		String ingredientName = "Lamb";
		double quantity = 2.0;
		String unit = "pound";
		String description = "cut into pieces";
		Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, description);
		assertEquals(ingredientName, ingredient.getIngredientName());
		assertEquals(quantity, ingredient.getQuantity(), 0);
		assertEquals(unit, ingredient.getUnit());
		assertEquals(description, ingredient.getDescription());
	}

	@Test
	public void testToString() throws ClassNotFoundException, SQLException {
		String ingredientName = "Lamb";
		double quantity = 2.0;
		String unit = "pound";
		String description = "cut into pieces";
		Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, description);
		assertEquals("Ingredient [ingredientName=Lamb, quantity=2.0, unit=pound, description=cut into pieces]"+"\n", ingredient.toString());

	}

}
