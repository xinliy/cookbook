package JUnit_Test;


import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import business_logic.Ingredient;
import business_logic.Recipe;
import business_logic.Tag;

public class RecipeTest {

	static private Recipe recipe;

	@BeforeClass
	public static void setUp() throws ClassNotFoundException, SQLException {
		recipe = new Recipe(21, "Tomato and egg", "Shanghai", 4);
		recipe.addIngredient(new Ingredient("cornstarch", 1.0, "tablespoon"));
		recipe.addIngredient(new Ingredient("Tomato", 2.0, "tablespoon"));
		recipe.addPreparationStep("Mix together cornstarch and 1 tbsp. of the soy sauce in a medium bowl.");
		recipe.setPreparationTime(30);
		recipe.setCookingTime(10);
		recipe.addTag(new Tag("sweet"));
	}


	@Test
	public void testAddIngredient() {

		assertEquals(2, recipe.getIngredient().size());
	}

	@Test
	public void testAddPreparationStep() {

		assertEquals(1, recipe.getSteps().size());

	}

	@Test
	public void testAddTag() {

		assertEquals(1, recipe.getTagList().size());

	}


	@Test
	public void testReviseServings() {
		
		recipe.reviseServings(8);
		assertEquals(2.0,recipe.getIngredient().get(0).getQuantity(),0);
		assertEquals(4.0,recipe.getIngredient().get(1).getQuantity(),0);

	}
	

}
