package JUnit_Test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.LinkedList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import business_logic.CookBook;
import business_logic.DBConnector;
import business_logic.Ingredient;
import business_logic.Recipe;
import business_logic.Tag;
import view.Create_GUI;
import view.Edit_GUI;
import view.Search_GUI;
import view.View_GUI;

/**
 * JUnit Testing of class DBConnector
 * 
 * @author Bing Guanqi
 * @version 1.0
 *
 */
public class DBConnectorTest {

	private static DBConnector db;
	private Recipe testRecipe;
	private Recipe testRecipe2;
	private CookBook cookBook;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		db = new DBConnector();
		db.getAccess();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		db.close();
	}

	@Before
	public void setUp() throws Exception {
		new Create_GUI();
		new Edit_GUI();
		new Search_GUI();
		new View_GUI();
		this.cookBook = new CookBook("testCookBook");
		this.testRecipe = new Recipe(100, "test recipe", "fh-luebeck", 4);
		this.testRecipe2 = new Recipe(101, "test recipe", "fh-luebeck", 6);
		this.testRecipe.addIngredient(new Ingredient("Shaoxin rice wine", 1.0, "tablespoon"));
		this.testRecipe.addIngredient(new Ingredient("dark soy sauce", 4.0, "teaspoon"));
		this.testRecipe2.addIngredient(new Ingredient("Shaoxin rice", 2.0, "tablespoon"));
		this.testRecipe.addPreparationStep("Mix together cornstarch and 1 tbsp. of the soy sauce in a medium bowl.");
		this.testRecipe.addPreparationStep("Add chicken, toss well, and set aside to marinate for 30 minutes.");
		this.testRecipe2.addPreparationStep("Add chicken");
		this.testRecipe.setPreparationTime(80);
		this.testRecipe2.setPreparationTime(20);
		this.testRecipe.setCookingTime(40);
		this.testRecipe2.setCookingTime(30);
		this.testRecipe.addTag(new Tag("sweet"));
		this.testRecipe.addTag(new Tag("salty"));
		this.testRecipe2.addTag(new Tag("sweet"));

		cookBook.add(testRecipe);
		cookBook.add(testRecipe2);
	}

	@After
	public void tearDown() throws Exception {
		db.deleteRecipe(testRecipe.getRecipeId());
		db.deleteRecipe(testRecipe2.getRecipeId());
	}

	@Test
	public void testDeleteRecipe() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()));
		db.deleteRecipe(testRecipe.getRecipeId());
		assertNotEquals(db.selectRecipeById(100).getDishName(), "test recipe");

	}

	@Test
	public void testAddRecipe() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()));
		db.deleteRecipe(testRecipe.getRecipeId());
	}

	@Test
	public void testAddTag() throws ClassNotFoundException, SQLException {
		db.addTag(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()).getTagList());
		db.removeAllTag(testRecipe);
	}

	@Test
	public void testAddPreparationStep() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		db.addPreparationStep(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()).getSteps());
		db.removeAllSteps(testRecipe);
	}

	@Test
	public void testAddRecipeTag() throws ClassNotFoundException, SQLException {
		db.addTag(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()).getTagList());
		db.removeAllTag(testRecipe);
	}

	@Test
	public void testAddRecipeIngredient() throws ClassNotFoundException, SQLException {
		db.addIngredients(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()).getIngredient());
		db.removeAllIngredients(testRecipe);
	}

	@Test
	public void testAddIngredients() throws ClassNotFoundException, SQLException {
		db.addIngredients(testRecipe);
		assertNotNull(cookBook.getRecipe(testRecipe.getDishName()).getIngredient());
		db.removeAllIngredients(testRecipe);
	}

	@Test
	public void testUpdateRecipe() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		testRecipe.setPreparationTime(5);
		testRecipe.setCookingTime(10);
		testRecipe.setDishName("update recipe");
		testRecipe.setLocation("haha");
		testRecipe.setServings(8);
		db.updateRecipe(testRecipe);
		assertNotEquals(testRecipe.getPreparationTime(), 80);
		assertNotEquals(testRecipe.getCookingTime(), 40);
		assertNotEquals(testRecipe.getDishName(), "test recipe");
		assertNotEquals(testRecipe.getServings(), 4);
		assertNotEquals(testRecipe.getLocation(), "nkd");
		db.deleteRecipe(testRecipe.getRecipeId());
	}

	@Test
	public void testSearch() throws ClassNotFoundException, SQLException {
		LinkedList<Recipe> recipeList = new LinkedList<Recipe>();
		recipeList = db.search("Hong", "All flavor");
		Recipe recipe = recipeList.get(0);
		assertEquals(recipe.getDishName(), "Hong Shao Rou");
	}

	@Test
	public void testSelectRecipeById() throws ClassNotFoundException, SQLException {
		Recipe recipe = db.selectRecipeById(1);
		assertEquals(recipe.getDishName(), "Gong Bao Jiding");
	}

	@Test
	public void testSelectIdByName() throws ClassNotFoundException, SQLException {
		int id = db.selectIdByName("Gong Bao Jiding");
		assertEquals(id, 1);
	}

	@Test
	public void testSelectRecipeByName() throws ClassNotFoundException, SQLException {
		Recipe recipe = db.selectRecipeByName("Gong Bao Jiding");
		assertEquals(recipe.getRecipeId(), 1);
	}

	@Test
	public void testCreateMaxRecipeId() throws ClassNotFoundException, SQLException {
		int maxRecipeId = db.createMaxRecipeId();
		assertEquals(maxRecipeId, 5);
	}

	@Test
	public void testRemoveAllTag() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		db.addTag(testRecipe);
		db.removeAllTag(testRecipe);
		assertNotNull(db.selectRecipeById(100).getTagList());
		db.deleteRecipe(testRecipe.getRecipeId());
	}

	@Test
	public void testRemoveAllIngredients() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		db.addIngredients(testRecipe);
		db.removeAllIngredients(testRecipe);
		assertNotNull(db.selectRecipeById(100).getIngredient());
		db.deleteRecipe(testRecipe.getRecipeId());
	}

	@Test
	public void testRemoveAllSteps() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		db.removeAllSteps(testRecipe);
		assertNotNull(db.selectRecipeById(100).getSteps());
		db.deleteRecipe(testRecipe.getRecipeId());
	}
	
	@Test
	public void testSelectDishnameById() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		assertEquals(db.selectDishnameById(100), "test recipe");
		db.deleteRecipe(testRecipe.getRecipeId());
	}

	@Test
	public void testCheckSameName() throws ClassNotFoundException, SQLException {
		db.addRecipe(testRecipe);
		db.addRecipe(testRecipe2);
		assertFalse(db.checkSameName("test recipe"));
		db.deleteRecipe(testRecipe.getRecipeId());
		db.deleteRecipe(testRecipe2.getRecipeId());
	}
	
}
