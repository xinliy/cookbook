package JUnit_Test;


import static org.junit.Assert.*;

import org.junit.Test;

import business_logic.Tag;

public class TagTest {

	@Test
	public void testTag() {
		
		String tagContent = "Spicy";
		Tag tag = new Tag(tagContent);
		assertEquals(tagContent,tag.getTagContent());
		
	}

}
