package JUnit_Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ CookBookTest.class, RecipeTest.class, IngredientTest.class, TagTest.class })
public class ModelTestSuite {
}
