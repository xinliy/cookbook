package SelfDefException;

import javax.swing.JOptionPane;

/**
 * The class to show a message dialogue with specified information
 * 
 * @author Bing Guanqi
 * @version 1.0
 */

public class InputException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor
	 */
	
	public InputException() {

	}

	public InputException(String msg) {

		JOptionPane.showMessageDialog(null, msg);

	}
}
