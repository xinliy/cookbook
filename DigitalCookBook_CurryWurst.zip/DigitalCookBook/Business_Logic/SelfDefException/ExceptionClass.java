package SelfDefException;

import java.util.regex.Pattern;

import javax.swing.JOptionPane;

/**
 * The class to check whether the user has filled in the right information
 * 
 * Used in Edit_GUI and Create_GUI
 * 
 * @author Bing Guanqi
 * @version 1.0
 */

public class ExceptionClass {

	private boolean isRecipeNameValid;
	private boolean isIngredientNameValid;
	private boolean isIngredientUnitValid;
	private boolean isIngredientQuantityValid;
	private boolean isPrepTimeValid;
	private boolean isCookTimeValid;

	/**
	 * Constructor which initializes all the boolean variables
	 */

	public ExceptionClass() {
		isRecipeNameValid = true;
		isIngredientNameValid = true;
		isIngredientQuantityValid = true;
		isIngredientUnitValid = true;
		isPrepTimeValid = true;
		isCookTimeValid = true;

	}

	/**
	 * Check whether the recipe name is correctly typed
	 * 
	 * @param name
	 *            =>The recipe name to be checked
	 * @throws InputException
	 */
	public void checkRecipeName(String name) throws InputException {
		String[] word = name.split(" ");
		for (int i = 0; i < word.length; i++) {
			if (Pattern.matches("^[A-Za-z]+$", word[i])) {
				isRecipeNameValid = true;
			} else {
				isRecipeNameValid = false;
				throw new InputException("The name of recipe should consists of only letters and spaces!");
			}
		}
	}

	/**
	 * Check whether the ingredient name is correctly typed
	 * 
	 * @param name
	 *            =>The ingredient name to be checked
	 * @throws InputException
	 */

	public void checkIngredientName(String name) throws InputException {
		String[] word = name.split(" ");
		for (int i = 0; i < word.length; i++) {
			if (Pattern.matches("^[A-Za-z]+$", word[i])) {
				isIngredientNameValid = true;
			} else {
				isIngredientNameValid = false;
				throw new InputException("The names of ingredients should consists of only letters and spaces!");
			}
		}
	}

	/**
	 * Check whether the ingredient quantity is correctly typed
	 * 
	 * @param quantity
	 *            =>The quantity to be checked
	 * @throws InputException
	 */

	public void checkIngredientQuantity(String quantity) throws InputException {
		if (Pattern.matches("^[0-9]+(.[0-9]{1,3})?$", quantity)) {
			isIngredientQuantityValid = true;
		} else {
			isIngredientNameValid = false;
			throw new InputException("The quantity of ingredients should consists of only numbers!");
		}
	}

	/**
	 * Check whether the ingredient unit is correctly typed
	 * 
	 * @param unit
	 *            =>The ingredient unit to be checked
	 * @throws InputException
	 */

	public void checkIngredientUnit(String unit) throws InputException {
		String[] word = unit.split(" ");
		for (int i = 0; i < word.length; i++) {
			if (Pattern.matches("^[A-Za-z]+$", word[i])) {
				isIngredientUnitValid = true;
			} else {
				isIngredientNameValid = false;
				throw new InputException("The units of ingredients should consists of only letters and spaces!");
			}
		}
	}

	/**
	 * Check whether the preparing time is correctly typed
	 * 
	 * @param prepTime
	 *            => The preparing time to be checked
	 * @throws InputException
	 */

	public void checkPrepTime(String prepTime) throws InputException {
		if (Pattern.matches("^[0-9]*[1-9][0-9]*$", prepTime)) {
			isPrepTimeValid = true;
		} else {
			isPrepTimeValid = false;
			throw new InputException("The prepare time should be positive whole number!");
		}
	}

	/**
	 * Check whether the cooking time is correctly typed
	 * 
	 * @param cookTime
	 *            =>The cooking time to be checked
	 * @throws InputException
	 */

	public void checkCookTime(String cookTime) throws InputException {
		if (Pattern.matches("^[0-9]*[1-9][0-9]*$", cookTime)) {
			isCookTimeValid = true;
		} else {
			isCookTimeValid = false;
			throw new InputException("The cooking time should be positive whole number!");
		}
	}

	/**
	 * Check whether all the recipe information is correctly filled in
	 * 
	 * @throws InputException
	 */

	public void checkRecipe() throws InputException {
		if ((isRecipeNameValid == true) && (isIngredientNameValid == true)
				&& (isIngredientUnitValid == true && (isIngredientQuantityValid == true)) && (isPrepTimeValid == true)
				&& (isCookTimeValid == true)) {
			JOptionPane.showMessageDialog(null, "You have saved new recipe successfully!");
		} else {
			throw new InputException();
		}
	}

}
