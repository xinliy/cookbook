package business_logic;

import java.io.Serializable;
import java.sql.SQLException;

/**
 * The ingredient class in the project
 * 
 * @author Bing Guanqi
 * @version 1.0
 */

@SuppressWarnings("serial")

public class Ingredient implements Serializable {

	private String ingredientName;
	private double quantity;
	private String unit;
	private String description;

	/**
	 * Constructor which specifies the ingredient name, quantity and unit
	 * 
	 * @param ingredientName
	 *            =>The ingredient name
	 * @param quantity
	 *            =>The ingredient quantity
	 * @param unit
	 *            =>The ingredient unit
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public Ingredient(String ingredientName, double quantity, String unit) throws ClassNotFoundException, SQLException {

		this.ingredientName = ingredientName;
		this.quantity = quantity;
		this.unit = unit;

	}

	/**
	 * Constructor which specifies the ingredient name, quantity,unit and
	 * description
	 * 
	 * @param ingredientName
	 *            =>The ingredient name
	 * @param quantity
	 *            =>The ingredient quantity
	 * @param unit
	 *            =>The ingredient unit
	 * @param description
	 *            =>The ingredient description
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * 
	 */

	public Ingredient(String ingredientName, double quantity, String unit, String description)
			throws ClassNotFoundException, SQLException {

		this.ingredientName = ingredientName;
		this.quantity = quantity;
		this.unit = unit;
		this.description = description;

	}

	public String getIngredientName() {
		return ingredientName;
	}

	public double getQuantity() {
		return quantity;
	}

	public String getUnit() {
		return unit;
	}

	public String getDescription() {
		return description;
	}

	public void setIngredientName(String newIngredientName) {
		ingredientName = newIngredientName;
	}

	public void setQuantity(Double newQuantity) {
		quantity = newQuantity;
	}

	public void setUnit(String newUnit) {
		unit = newUnit;
	}

	/**
	 * Overriding the method of toString
	 */

	@Override

	public String toString() {

		return "Ingredient [ingredientName=" + ingredientName + ", quantity=" + quantity + ", unit=" + unit

				+ ", description=" + description + "]" + "\n";
	}

}