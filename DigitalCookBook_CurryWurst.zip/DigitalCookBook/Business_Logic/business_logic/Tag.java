package business_logic;

/**
 * The tag class
 * 
 * @author Bing Guanqi
 * @version 1.0
 */

public class Tag {

	private String tagContent;

	/**
	 * The constructor which specifies the flavor information
	 * 
	 * @param tagId
	 *            =>The ID of a tag
	 * @param tagContent
	 *            =>The content of the tag
	 */

	public Tag(String tagContent) {
		this.tagContent = tagContent;
	}

	public String getTagContent() {
		return this.tagContent;
	}

	public void setTagContent(String tagContent) {
		this.tagContent = tagContent;
	}

}