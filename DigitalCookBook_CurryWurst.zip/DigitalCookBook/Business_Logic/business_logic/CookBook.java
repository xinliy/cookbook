package business_logic;

import java.awt.event.ActionListener;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.swing.JComboBox;

/**
 * The cook book class
 * 
 * @author Song Yuchao, Ma Qiang, Shan Xue
 * @version 1.0
 */

public class CookBook implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cookBookName;
	private LinkedList<Recipe> recipeList = new LinkedList<Recipe>();
	private Recipe recipe;

	/**
	 * Default constructor
	 * 
	 */

	public CookBook() {

	}

	/**
	 * Constructor which specifies the name of the cook book
	 * 
	 * @param cookBookName
	 *            =>The name of the cook book
	 */

	public CookBook(String cookBookName) {

		this.cookBookName = cookBookName;

	}

	/**
	 * Adding recipes to the cook book
	 * 
	 * @param recipe
	 *            =>The recipe to be added
	 */

	public void add(Recipe recipe) {

		this.recipeList.add(recipe);

	}

	/**
	 * Getting recipes with specified name
	 * 
	 * @param name
	 *            =>The recipe name
	 * 
	 * @return Recipes with specified name
	 * 
	 */

	public Recipe getRecipe(String name) {

		Recipe buf = null;
		for (Recipe i : recipeList) {
			if (i.getDishName().equals(name)) {
				buf = i;
			}
		}
		return buf;

	}

	/**
	 * Retrieving recipes with specified name from database
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return Recipes with specified name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public Recipe catchRecipe(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		recipe = dbConnector.selectRecipeByName(recipeName);
		dbConnector.close();
		return recipe;

	}

	/**
	 * Deriving the number of ingredients in a specified recipe
	 * 
	 * @param recipeName
	 *            =>Recipe name
	 * @return Number of ingredients
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int getIngredientNumber(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		int result = dbConnector.selectRecipeByName(recipeName).getIngredient().size();
		dbConnector.close();
		return result;

	}

	/**
	 * Deriving the number of steps in a specified recipe
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return Number of steps
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int getStepNumber(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		int result = dbConnector.selectRecipeByName(recipeName).getSteps().size();
		dbConnector.close();
		return result;

	}

	/**
	 * Deriving the step with specified index in a specified recipe
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @param number
	 *            =>The index number
	 * @return The step with specified index in a specified recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public String getStepSentence(String recipeName, int number) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		String stepSentence = dbConnector.selectRecipeByName(recipeName).getSteps().get(number);
		dbConnector.close();
		return stepSentence;

	}

	/**
	 * Deriving the sentence of the ingredient with specified index in a
	 * specified recipe
	 * 
	 * @param recipe
	 *            =>The recipe
	 * @param number
	 *            =>The number of index
	 * @return The sentence of the ingredient with specified index in a
	 *         specified recipe
	 */

	public String getInsideIngredientSentence(Recipe recipe, int number) {

		DBConnector dbConnector = new DBConnector();
		Ingredient ingredient = recipe.getIngredient().get(number);
		String ingredientSentence;
		if (ingredient.getDescription().equals("null")) {
			ingredientSentence = ingredient.getIngredientName() + " " + String.valueOf(ingredient.getQuantity()) + " "
					+ ingredient.getUnit();

		} else {
			ingredientSentence = ingredient.getIngredientName() + " " + String.valueOf(ingredient.getQuantity()) + " "
					+ ingredient.getUnit() + " " + ingredient.getDescription();

		}

		dbConnector.close();
		return ingredientSentence;

	}

	/**
	 * Deriving a brief ingredients information in a specified recipe
	 * 
	 * Used in Search_GUI
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return A brief ingredients information in a specified recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public String getAllIngredientsName(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		Recipe recipe = dbConnector.selectRecipeByName(recipeName);
		LinkedList<Ingredient> targetIngredients = recipe.getIngredient();
		String ingredients = "";
		if (recipe.getIngredient().size() == 1) {
			ingredients = ingredients + targetIngredients.get(0).getIngredientName();
		} else {
			ingredients = ingredients + targetIngredients.get(0).getIngredientName() + ", ";
			ingredients = ingredients + targetIngredients.get(1).getIngredientName() + "...";
		}

		dbConnector.close();
		return ingredients;

	}

	/**
	 * Deriving the LinkedList of tags in a specified recipe
	 * 
	 * Used in Search_GUI
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return The LinkedList of tags in a specified recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public LinkedList<String> getAllTags(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		Recipe recipe = dbConnector.selectRecipeByName(recipeName);
		LinkedList<Tag> targetTags = new LinkedList<Tag>();
		targetTags = recipe.getTagList();
		LinkedList<String> targetTagsList = new LinkedList<String>();
		for (int i = 0; i < targetTags.size(); i++) {
			String targetTagsContent = targetTags.get(i).getTagContent();
			targetTagsList.add(targetTagsContent);
		}
		dbConnector.close();
		return targetTagsList;

	}

	/**
	 * Deriving the LinkedList of recipes with specified name and flavor
	 * 
	 * Used in Search_GUI
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @param tagContent
	 *            =>The flavor tag
	 * @return The LinkedList of recipes with specified name and flavor
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public LinkedList<Recipe> searchByNameAndIngredient(String recipeName, String tagContent)
			throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		recipeList = dbConnector.search(recipeName, tagContent);
		dbConnector.close();
		return recipeList;
	}

	/**
	 * Deriving the new recipe ID in the database
	 * 
	 * Used in Create_GUI
	 * 
	 * @return The new ID number
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int getRecipeId() throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		int result = dbConnector.createMaxRecipeId();
		dbConnector.close();
		return result;

	}

	/**
	 * Sending the recipe to the database
	 * 
	 * Used in Create_GUI
	 * 
	 * @param recipe
	 *            =>The recipe to be sent
	 * @throws SQLException
	 */

	public void returnRecipe(Recipe recipe) throws SQLException {

		DBConnector dbConnector = new DBConnector();
		recipe.recipeToDatabase(dbConnector);
		dbConnector.close();

	}

	/**
	 * Delete the recipe with specified ID in database
	 * 
	 * @param id
	 *            =>The recipe ID
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void deleteRecipe(int id) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.deleteRecipe(id);
		dbConnector.close();

	}

	/**
	 * Remove all the tags in specified recipe
	 * 
	 * @param recipe
	 *            =>The recipe whose tags are to be removed
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllTag(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.removeAllTag(recipe);
		dbConnector.close();

	}

	/**
	 * Add an ActionListener to a button
	 * 
	 * @param listen
	 *            =>The ActionListener to be added
	 * @param button
	 *            =>The button be to have an ActionListener
	 */

	public void addListener(ActionListener listen, JComboBox<Integer> button) {

		DBConnector dbConnector = new DBConnector();
		button.addActionListener(listen);
		dbConnector.close();

	}

	/**
	 * Deriving the recipe ID with specified recipe name
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return The recipe ID with specified recipe name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int selectIdByName(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		int result = dbConnector.selectIdByName(recipeName);
		dbConnector.close();
		return result;

	}

	/**
	 * Updating the recipe into the database
	 * 
	 * @param recipe
	 *            =>The latest recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void updateRecipe(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.updateRecipe(recipe);
		dbConnector.close();

	}

	/**
	 * Adding the tags from specified recipe to database
	 * 
	 * @param recipe
	 *            =>The recipe whose tags are to be added
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void addRecipeTag(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.addRecipeTag(recipe);
		dbConnector.close();

	}

	/**
	 * Removing all the ingredients from specified recipe
	 * 
	 * @param recipe
	 *            =>The recipe whose ingredients are to be removed totally
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllIngredients(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.removeAllIngredients(recipe);
		dbConnector.close();

	}

	/**
	 * Removing all the steps from specified recipe
	 * 
	 * @param recipe
	 *            =>The recipe whose steps are to be removed totally
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllSteps(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.removeAllSteps(recipe);
		dbConnector.close();

	}

	/**
	 * Adding the ingredients from specified recipe into database
	 * 
	 * @param recipe
	 *            =>The recipe whose ingredients are to be added into
	 *            database(ingredient table)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void addIngredient(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.addIngredients(recipe);
		dbConnector.close();

	}

	/**
	 * Adding the ingredients from specified recipe into database
	 * 
	 * @param recipe
	 *            =>The recipe whose ingredients are to be added into
	 *            database(recipe_has_ingredients table)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void addRecipeIngredient(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.addRecipeIngredient(recipe);
		dbConnector.close();

	}

	/**
	 * Adding the steps from specified recipe into database
	 * 
	 * @param recipe
	 *            =>The recipe whose steps are to be added
	 * @throws ClassNotFoundException
	 */

	public void addPreparationStep(Recipe recipe) throws ClassNotFoundException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.addPreparationStep(recipe);
		dbConnector.close();

	}

	/**
	 * Deriving the dish name by ID
	 * 
	 * @param id
	 *            =>The ID of a recipe
	 * @return The dish name of the recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public String selectDishnameById(int id) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		String result = dbConnector.selectDishnameById(id);
		dbConnector.close();
		return result;

	}

	/**
	 * Judging whether there are several recipes which has the same name
	 * 
	 * @param recipeName
	 *            =>The recipe name to be checked
	 * @return true or false
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public boolean checkSameName(String recipeName) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		boolean result = dbConnector.checkSameName(recipeName);
		dbConnector.close();
		return result;

	}

	/**
	 * Updating the ingredients from specified recipe into database
	 * 
	 * @param recipe
	 *            =>The recipe whose ingredients are to be updated
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void updateIngredient(Recipe recipe) throws ClassNotFoundException, SQLException {

		DBConnector dbConnector = new DBConnector();
		dbConnector.updateIngredients(recipe);
		dbConnector.close();

	}

	/**
	 * Replacing all the "'" character in the string to "\\" to avoid database
	 * error
	 * 
	 * @param input
	 *            =>The string to be replaced
	 * @return The modified string
	 */

	public String replaceSingleQuote(String input) {
		return input.replace("'", "\\'");
	}

	public String getCookBookName() {
		return cookBookName;
	}

	public void setCookBookName(String cookBookName) {
		this.cookBookName = cookBookName;
	}

	public LinkedList<Recipe> getRecipeList() {
		return recipeList;
	}

	public void setRecipeList(LinkedList<Recipe> recipeList) {
		this.recipeList = recipeList;
	}

}