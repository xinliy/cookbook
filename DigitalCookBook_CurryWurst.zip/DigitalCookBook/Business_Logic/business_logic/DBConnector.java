package business_logic;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The class to connect the java code to database
 * 
 * @author Zhang Xiaoyue�� Ma Qiang
 * 
 * @version 1.0
 */

public class DBConnector {

	private Connection connection = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	private Recipe recipe;

	/**
	 * Getting the access to the database
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void getAccess() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");

		// Setup the connection with the DB
		String port = "3306";
		String databaseName = "cookbook";
		String password = "";
		String userName = "root";
		
		connection = DriverManager.getConnection("jdbc:mysql://localhost:"+ port + "/" + databaseName, userName  , password);
		statement = connection.createStatement();

	}

	/**
	 * Delete the recipe with specified ID in database
	 * 
	 * @param id
	 *            =>The recipe ID
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void deleteRecipe(int id) throws SQLException, ClassNotFoundException {

		getAccess();
		preparedStatement = connection.prepareStatement("delete from recipe where recipeId = '" + id + "';");
		preparedStatement.executeUpdate();
		close();

	}

	/**
	 * Adding the recipe to the database
	 * 
	 * @param r
	 *            =>The recipe to be added
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void addRecipe(Recipe r) throws ClassNotFoundException, SQLException {

		getAccess();
		statement.executeUpdate(
				"INSERT INTO recipe (recipeId, dishName,location, servings, preparationTime, cookingTime) VALUES("
						+ r.getRecipeId() + ",'" + r.getDishName() + "', " + "'" + r.getLocation() + "',"
						+ r.getServings() + ", " + r.getPreparationTime() + ", " + r.getCookingTime() + ")");
		close();

	}

	/**
	 * Adding the tags into the recipe
	 * 
	 * @param r
	 *            =>The recipe whose tags are to be added
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void addTag(Recipe r) throws SQLException, ClassNotFoundException {

		getAccess();
		LinkedList<Tag> tags = r.getTagList();
		statement.executeUpdate("ALTER TABLE tag auto_increment =1");
		for (int i = 0; i < tags.size(); i++) {

			String query = "SELECT * from tag where tagContent = " + "'" + tags.get(i).getTagContent() + "'";
			resultSet = statement.executeQuery(query);
			try {

				statement.executeUpdate("INSERT INTO tag (tagContent) VALUES("+ "'" + tags.get(i).getTagContent() + "' ) ");

			} catch (SQLException exception) {}
		}
		close();
	}

	/**
	 * Adding the steps from specified recipe into database
	 * 
	 * @param r
	 *            =>The recipe whose steps are to be added
	 * @throws ClassNotFoundException
	 */

	public void addPreparationStep(Recipe r) throws ClassNotFoundException {

		try {

			getAccess();
			LinkedList<String> steps = r.getSteps();
			for (int j = 0; j < steps.size(); j++) {

				statement.executeUpdate("INSERT INTO preparation_step(recipeId,step, description) VALUES("
						+ r.getRecipeId() + "," + (j + 1) + ", " + "'" + steps.get(j) + "')");
			}
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		close();
	}

	/**
	 * Adding the tags from specified recipe to database
	 * 
	 * @param r
	 *            =>The recipe whose tags are to be added
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void addRecipeTag(Recipe r) throws SQLException, ClassNotFoundException {

		getAccess();
		LinkedList<Tag> tag = r.getTagList();
		for (int i = 0; i < tag.size(); i++) {

			String query = "SELECT * from tag where tagContent = " + "'" + tag.get(i).getTagContent() + "'";
			resultSet = statement.executeQuery(query);
			resultSet.next();
			int id = resultSet.getInt("tagId");
			statement.executeUpdate("INSERT INTO recipe_has_tag (recipe_recipeId, tag_tagId) VALUES(" + r.getRecipeId()
					+ ",'" + id + "' " + ")");
		}
		close();
	}

	/**
	 * Adding the ingredients from specified recipe into database
	 * 
	 * @param r
	 *            =>The recipe whose ingredients are to be added into
	 *            database(recipe_has_ingredients table)
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void addRecipeIngredient(Recipe r) throws SQLException, ClassNotFoundException {

		getAccess();
		LinkedList<Ingredient> ingredient = r.getIngredient();
		for (int i = 0; i < ingredient.size(); i++) {

			String query = "SELECT * from ingredients where ingredientName = " + "'"
					+ ingredient.get(i).getIngredientName() + "'";
			resultSet = statement.executeQuery(query);
			resultSet.next();
			int id2 = resultSet.getInt("ingredientId");
			statement.executeUpdate(

					"INSERT INTO recipe_has_ingredients (recipe_recipeId, ingredients_ingredientId, quantity, unit, description) VALUES("
							+ r.getRecipeId() + ",'" + id2 + "', " + ingredient.get(i).getQuantity() + ", " + "'"
							+ ingredient.get(i).getUnit() + "'," + "'" + ingredient.get(i).getDescription() + "')");
		}
		close();
	}

	/**
	 * Adding the ingredients from specified recipe into database
	 * 
	 * @param r
	 *            =>The recipe whose ingredients are to be added into
	 *            database(ingredients table)
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void addIngredients(Recipe r) throws SQLException, ClassNotFoundException {

		getAccess();
		LinkedList<Ingredient> ingredient = r.getIngredient();
		statement.executeUpdate("alter table ingredients auto_increment = 1");
		for (int i = 0; i < ingredient.size(); i++) {

			try {

				statement.executeUpdate("INSERT INTO ingredients (ingredientName) VALUES(" + "'"
						+ ingredient.get(i).getIngredientName() + "' ) ");

			} catch (SQLException e) {
			}
		}
		close();
	}

	/**
	 * Updating the ingredients from specified recipe into database
	 * 
	 * @param r
	 *            =>The recipe whose ingredients are to be updated
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public void updateIngredients(Recipe r) throws SQLException, ClassNotFoundException {

		getAccess();
		LinkedList<Ingredient> ingredient = r.getIngredient();
		statement.executeUpdate("alter table ingredients auto_increment = 1");
		for (int i = 0; i < ingredient.size(); i++) {

			try {

				String sql = "select ingredientName from ingredients";
				resultSet = statement.executeQuery(sql);

				while (resultSet.next()) {

					String ingredient_name = resultSet.getString("ingredientName");
					if (!ingredient_name.equals(r.getIngredient().get(i).getIngredientName())) {

						statement.executeUpdate("INSERT INTO ingredients (ingredientName) VALUES(" + "'"
								+ ingredient.get(i).getIngredientName() + "' ) ");
					}
				}

			} catch (SQLException e) {
			}
		}
		close();
	}

	/**
	 * Updating the recipe into the database
	 * 
	 * @param r
	 *            =>The latest recipe
	 * @throws ClassNotFounThe
	 *             latest recipeException
	 * @throws SQLException
	 */

	public void updateRecipe(Recipe r) throws ClassNotFoundException, SQLException {

		getAccess();
		String sql = "update recipe set dishName =? ,location = ?,servings = ?,preparationTime = ?,cookingTime = ? where recipeId=?";
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, r.getDishName());
		preparedStatement.setString(2, r.getLocation());
		preparedStatement.setInt(3, r.getServings());
		preparedStatement.setInt(4, r.getPreparationTime());
		preparedStatement.setInt(5, r.getCookingTime());
		preparedStatement.setInt(6, r.getRecipeId());
		preparedStatement.executeUpdate();
		close();

	}

	/**
	 * Judging whether there are several recipes which has the same name
	 * 
	 * @param recipeName
	 *            =>The recipe name to be checked
	 * @return true or false
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public boolean checkSameName(String recipeName) throws SQLException, ClassNotFoundException {
		getAccess();
		String sql = "select dishName from recipe";
		resultSet = statement.executeQuery(sql);
		while (resultSet.next()) {

			String dishName = resultSet.getString("dishName");
			if (dishName.equals(recipeName)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Deriving the dish name by ID
	 * 
	 * @param id
	 *            =>The ID of a recipe
	 * @return The dish name of the recipe
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public String selectDishnameById(int id) throws ClassNotFoundException, SQLException {
		getAccess();
		String dishname = null;
		String sql = "select dishname from recipe where recipeId =" + "'" + id + "'";
		resultSet = statement.executeQuery(sql);
		while (resultSet.next()) {
			dishname = resultSet.getString("dishname");
		}
		return dishname;
	}

	/**
	 * Deriving the LinkedList of recipes with specified name and flavor
	 * 
	 * @param input
	 *            =>The recipe name
	 * @param tagContent
	 *            =>The flavor tag
	 * @return The LinkedList of recipes with specified name and flavor
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public LinkedList<Recipe> search(String input, String tagContent) throws SQLException, ClassNotFoundException {

		getAccess();

		LinkedList<Integer> idlist1 = new LinkedList<>();
		LinkedList<Integer> idlist2 = new LinkedList<>();
		LinkedList<Recipe> recipeList = new LinkedList<>();

		// All flavor match all tags.
		if (tagContent.equals("All flavor")) {
			tagContent = "%";
		}

		// Fuzzy search, match more results.
		String input_notexactly = "%" + input + "%";

		// Input will match all results.
		if (input.equals("")) {
			input = "Dish Name/Ingredient";
		}
		if (input.equals("Dish Name/Ingredient")) {
			input_notexactly = "%";
		}

		String searchRecipe = "  select DISTINCT t1.recipeId,t1.dishName from recipe as t1, tag as t2, recipe_has_tag as t3 "
				+ "where t1.recipeId=t3.recipe_recipeId and t2.tagId = t3.tag_tagId  and t1.dishName like '"
				+ input_notexactly + "' and t2.tagContent like '" + tagContent + "'";

		String searchIngredient = "select DISTINCT t1.recipe_recipeId, t2.ingredientName from recipe_has_ingredients as t1, ingredients as t2 "
				+ "where t1.ingredients_ingredientId = t2.ingredientId and t2.ingredientName like '" + input_notexactly
				+ "'"
				+ "and t1.recipe_recipeId IN (select t3.recipe_recipeId  from recipe_has_tag as t3, tag as t4 where t3.tag_tagId = t4.tagId and t4.tagContent like '"
				+ tagContent + "')" + "group by t1.recipe_recipeId";

		resultSet = statement.executeQuery(searchRecipe);

		// proceed matching all recipes.
		if (input.equals("Dish Name/Ingredient")) {
			while (resultSet.next()) {
				int searchResultId = resultSet.getInt("recipeId");
				idlist1.add(searchResultId);
			}
			for (int i = 0; i < idlist1.size(); i++) {
				recipeList.add(selectRecipeById(idlist1.get(i)));
			}
			return recipeList;
		}

		// Deal with matching recipes.
		if (!resultSet.next()) {

			System.out.println("Not a recipe!");

		} else {

			resultSet.beforeFirst();
			while (resultSet.next()) {

				String searchResult = resultSet.getString("dishName");
				int searchResultId = resultSet.getInt("recipeId");

				String[] word = searchResult.split("\\s+");
				String[] inputSplit = input.split("\\s+");

				if (inputSplit.length > 1) {
					String regex = "(.)*" + "[" + input + "]" + "(.)*";
					Pattern pattern = Pattern.compile(regex);
					Matcher matcher = pattern.matcher(searchResult);

					if (matcher.find()) {
						idlist1.add(searchResultId);
					}

				} else {
					for (String string : word) {
						if (string.equals(inputSplit[0])) {
							idlist1.add(searchResultId);
						}
					}
				}
			}
			for (int i = 0; i < idlist1.size(); i++) {

				recipeList.add(selectRecipeById(idlist1.get(i)));

			}
		}
		resultSet = statement.executeQuery(searchIngredient);

		// Deal with matching ingredients.
		if (!resultSet.next()) {

			System.out.println("Not a ingredient!");

		} else {

			resultSet.beforeFirst();

			while (resultSet.next()) {

				int searchResult = resultSet.getInt("recipe_recipeId");
				String ingredientName = resultSet.getString("ingredientName");
				String[] word = ingredientName.split("\\s+");
				String[] inputSplit = input.split("\\s+");

				if (inputSplit.length > 1) {
					String regex = "(.)*" + "[" + input + "]" + "(.)*";
					Pattern pattern = Pattern.compile(regex);
					Matcher matcher = pattern.matcher(ingredientName);
					if (matcher.find()) {
						idlist2.add(searchResult);
					}
				} else {
					for (String string : word) {

						if (string.equals(input)) {
							idlist2.add(searchResult);
						}
					}
				}

			}

		}

		for (int i = 0; i < idlist2.size(); i++) {

			recipeList.add(selectRecipeById(idlist2.get(i)));

		}

		return recipeList;

	}

	/**
	 * Deriving recipe with specified ID
	 * 
	 * @param RecipeId
	 *            =>The recipe ID
	 * @return The recipe with specified ID
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */

	public Recipe selectRecipeById(int RecipeId) throws SQLException, ClassNotFoundException {

		getAccess();
		String sql = "SELECT DISTINCT dishname from recipe, recipe_has_ingredients where recipe.recipeId= recipe_has_ingredients.recipe_recipeId and recipe_recipeId = "
				+ RecipeId;
		String dishName;
		resultSet = statement.executeQuery(sql);

		while (resultSet.next()) {

			dishName = resultSet.getString("dishName");
			recipe = selectRecipeByName(dishName);

		}
		return recipe;
	}

	/**
	 * Deriving the recipe ID with specified recipe name
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return The recipe ID with specified recipe name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int selectIdByName(String recipeName) throws ClassNotFoundException, SQLException {

		getAccess();
		int recipeId = 0;
		recipe = selectRecipeByName(recipeName);
		String sql = "select recipeId from recipe where dishname = " + "'" + recipe.getDishName() + "'";
		resultSet = statement.executeQuery(sql);
		while (resultSet.next()) {

			recipeId = resultSet.getInt("recipeId");

		}
		return recipeId;
	}

	/**
	 * Deriving the recipe with specified name
	 * 
	 * @param recipeName
	 *            =>The recipe name
	 * @return The recipe with specified name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public Recipe selectRecipeByName(String recipeName) throws ClassNotFoundException, SQLException {

		getAccess();
		Integer recipeId;
		String dishName;
		String location;
		Integer servings;
		Integer preparationTime;
		Integer cookingTime;
		String ingredientName;
		Integer quantity;
		String unit;
		String description;
		String tagContent;
		String sql = "SELECT * from recipe where recipe.dishName = " + "'" + recipeName + "'";
		resultSet = statement.executeQuery(sql);
		while (resultSet.next()) {

			recipeId = resultSet.getInt("recipeId");
			dishName = resultSet.getString("dishName");
			location = resultSet.getString("location");
			servings = resultSet.getInt("servings");
			preparationTime = resultSet.getInt("preparationTime");
			cookingTime = resultSet.getInt("cookingTime");
			recipe = new Recipe(recipeId, dishName, location, servings);
			recipe.setPreparationTime(preparationTime);
			recipe.setCookingTime(cookingTime);

		}

		String sql1 = "SELECT ingredientId, ingredientName, quantity, unit,description from recipe as t1, recipe_has_ingredients as t2, ingredients as t3 "
				+ "where t1.dishName = " + "'" + recipeName + "'"
				+ " and t1.recipeId = t2.recipe_recipeId and t2.ingredients_ingredientId = t3.ingredientId";

		resultSet = statement.executeQuery(sql1);
		while (resultSet.next()) {

			ingredientName = resultSet.getString("ingredientName");
			quantity = resultSet.getInt("quantity");
			unit = resultSet.getString("unit");
			description = resultSet.getString("description");

			if (description.equals(null)) {
				recipe.addIngredient(new Ingredient(ingredientName, quantity, unit));
			} else {
				recipe.addIngredient(new Ingredient(ingredientName, quantity, unit, description));
			}
		}

		String sql2 = "SELECT step, description from recipe, preparation_step where recipe.recipeId = preparation_step.recipeId and recipe.dishName = "
				+ "'" + recipeName + "'";
		resultSet = statement.executeQuery(sql2);
		while (resultSet.next()) {

			description = resultSet.getString("description");
			recipe.addPreparationStep(description);

		}

		String sql3 = "SELECT tagContent from recipe as t1, recipe_has_tag as t2, tag as t3 " + "where t1.dishName="
				+ "'" + recipeName + "'" + " and t1.recipeId=t2.recipe_recipeId and t2.tag_tagId= t3.tagId";

		resultSet = statement.executeQuery(sql3);
		while (resultSet.next()) {

			tagContent = resultSet.getString("tagContent");
			recipe.addTag(new Tag(tagContent));

		}
		return recipe;
	}

	/**
	 * Deriving the new recipe ID in the database
	 * 
	 * @return The new ID number
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public int createMaxRecipeId() throws ClassNotFoundException, SQLException {

		getAccess();
		String sql = "SELECT MAX(recipeId) FROM RECIPE";
		resultSet = statement.executeQuery(sql);
		int id = 0;
		while (resultSet.next()) {

			id = resultSet.getInt("Max(recipeId)");

		}
		return id + 1;
	}

	/**
	 * Remove all the tags in specified recipe
	 * 
	 * @param r
	 *            =>The recipe whose tags are to be removed
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllTag(Recipe r) throws ClassNotFoundException, SQLException {

		getAccess();
		preparedStatement = connection
				.prepareStatement("delete from recipe_has_tag where recipe_recipeId = " + r.getRecipeId() + ";");
		preparedStatement.executeUpdate();
		close();

	}

	/**
	 * Removing all the ingredients from specified recipe
	 * 
	 * @param r
	 *            =>The recipe whose ingredients are to be removed totally
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllIngredients(Recipe r) throws ClassNotFoundException, SQLException {

		getAccess();
		preparedStatement = connection
				.prepareStatement("delete from recipe_has_ingredients where recipe_recipeId =" + r.getRecipeId() + ";");
		preparedStatement.executeUpdate();
		close();

	}

	/**
	 * Removing all the steps from specified recipe
	 * 
	 * @param r
	 *            =>The recipe whose steps are to be removed totally
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	public void removeAllSteps(Recipe r) throws ClassNotFoundException, SQLException {

		getAccess();
		preparedStatement = connection
				.prepareStatement("delete from preparation_step where recipeId =" + r.getRecipeId() + ";");
		preparedStatement.executeUpdate();
		close();

	}

	/**
	 * Closing all the resultSet, statement and connection
	 */

	public void close() {

		try {

			if (resultSet != null) {
				resultSet.close();
				resultSet = null;
			}

			if (statement != null) {
				statement.close();
				statement = null;
			}

			if (connection != null) {
				connection.close();
				connection = null;
			}

		} catch (Exception e) {

		}

	}

}